import React, { useState, useEffect } from 'react';
import {
  Sparkles, Languages, Search, Wand2, Mic, Image as ImageIcon,
  Play, Monitor, ChevronRight, ArrowRight, Check,
  Globe, Layers, Music, BookOpen, Eye, Plus
} from 'lucide-react';

const FONT_DISPLAY = `'Fraunces', 'Times New Roman', serif`;
const FONT_BODY = `'Helvetica Neue', sans-serif`;
const FONT_MONO = `'JetBrains Mono', monospace`;

const LANG_NAMES = { en: 'English', es: 'Español', pt: 'Português', fr: 'Français', ko: '한국어', zh: '中文' };

const songs = [
  { id: 's1', title: 'Goodness of God', author: 'Bethel Music', key: 'C', slides: [
    { label: 'Verse 1', en: ['I love You, Lord', 'Oh, Your mercy never fails me'], es: ['Te amo, Señor', 'Tu misericordia nunca me falla'], pt: ['Eu Te amo, Senhor', 'Tua misericórdia nunca me falha'], fr: ['Je T\'aime, Seigneur', 'Ta miséricorde ne me manque jamais'], ko: ['주님, 사랑합니다', '주의 자비는 결코 실패하지 않습니다'], zh: ['我爱你，主', '你的怜悯永不失败'] },
    { label: 'Verse 1', en: ['All my days, I\'ve been held in Your hands'], es: ['Todos mis días he estado en Tus manos'], pt: ['Todos os meus dias estive em Tuas mãos'], fr: ['Tous mes jours j\'ai été dans Tes mains'], ko: ['내 모든 날, 주의 손에 있었네'], zh: ['我所有的日子都在你手中'] },
    { label: 'Chorus', en: ['All my life You have been faithful', 'All my life You have been so good'], es: ['Toda mi vida has sido fiel', 'Toda mi vida has sido tan bueno'], pt: ['Toda a minha vida foste fiel', 'Toda a minha vida foste tão bom'], fr: ['Toute ma vie Tu as été fidèle', 'Toute ma vie Tu as été si bon'], ko: ['내 평생 주는 신실하셨네', '내 평생 주는 참 좋으셨네'], zh: ['我一生你都信实', '我一生你都何等美善'] },
  ]},
  { id: 's2', title: 'Build My Life', author: 'Pat Barrett', key: 'E', slides: [
    { label: 'Verse 1', en: ['Worthy of every song we could ever sing'], es: ['Digno de cada canción que podamos cantar'], pt: ['Digno de cada canção que possamos cantar'], fr: ['Digne de chaque chant que nous pourrions chanter'], ko: ['우리가 부를 수 있는 모든 노래에 합당하신'], zh: ['配得我们所能唱的每首歌'] },
    { label: 'Chorus', en: ['Holy, there is no one like You', 'There is none beside You'], es: ['Santo, no hay nadie como Tú', 'No hay nadie más que Tú'], pt: ['Santo, não há ninguém como Tu', 'Não há ninguém além de Ti'], fr: ['Saint, il n\'y a personne comme Toi', 'Il n\'y a personne d\'autre que Toi'], ko: ['거룩하신 주 같은 이 없네', '주 외에 다른 이 없네'], zh: ['圣哉，无人像你', '除你以外，再无别人'] },
  ]},
  { id: 's3', title: 'Way Maker', author: 'Sinach', key: 'D', slides: [
    { label: 'Verse 1', en: ['You are here, moving in our midst'], es: ['Estás aquí, moviéndote entre nosotros'], pt: ['Estás aqui, movendo-Te entre nós'], fr: ['Tu es ici, agissant parmi nous'], ko: ['주님 여기 우리 가운데 역사하시네'], zh: ['你在这里，在我们中间运行'] },
    { label: 'Chorus', en: ['Way maker, miracle worker', 'Promise keeper, light in the darkness'], es: ['Hacedor de caminos, obrador de milagros', 'Cumplidor de promesas, luz en la oscuridad'], pt: ['Abridor de caminhos, operador de milagres', 'Cumpridor de promessas, luz nas trevas'], fr: ['Faiseur de chemins, faiseur de miracles', 'Gardien des promesses, lumière dans les ténèbres'], ko: ['길을 만드시는 분, 기적을 행하시는 분', '약속을 지키시는 분, 어둠 속의 빛'], zh: ['开路者，行神迹者', '守约者，黑暗中的光'] },
  ]},
];

const aiSuggestions = [
  { type: 'order', text: 'Move "Way Maker" before opening prayer for stronger emotional arc' },
  { type: 'language', text: 'Audience analysis suggests adding Portuguese tonight (12% PT speakers detected)' },
  { type: 'background', text: 'Generated 4 cinematic backgrounds matching tonight\'s theme of "grace"' },
];

export default function LumoraDemo() {
  const [view, setView] = useState('landing');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 50);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="min-h-screen w-full bg-white text-black overflow-x-hidden" style={{ fontFamily: FONT_BODY }}>
      <style>{`
        @keyframes fadeUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulse-dot { 0%,100% { opacity:1; } 50% { opacity:0.4; } }
        @keyframes thinking { 0%,100% { opacity:0.3; } 50% { opacity:1; } }
        .fade-up { animation: fadeUp 0.8s cubic-bezier(0.16,1,0.3,1) forwards; opacity:0; }
        .thinking-dot { animation: thinking 1.4s infinite; }
        .thinking-dot:nth-child(2) { animation-delay: 0.2s; }
        .thinking-dot:nth-child(3) { animation-delay: 0.4s; }
        .scrollbar-thin::-webkit-scrollbar { width: 4px; }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: #ddd; border-radius: 4px; }
      `}</style>
      {view === 'landing' ? <Landing onLaunch={() => setView('app')} mounted={mounted} /> : <AppDemo onBack={() => setView('landing')} />}
    </div>
  );
}

function LumoraMark({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="15" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="16" cy="16" r="6" fill="currentColor" />
    </svg>
  );
}

function Landing({ onLaunch, mounted }) {
  return (
    <div className="relative">
      <nav className="fixed top-0 left-0 right-0 z-40 backdrop-blur-xl bg-white/70 border-b border-black/5">
        <div className="max-w-[1400px] mx-auto px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LumoraMark />
            <span className="text-[15px] tracking-tight font-medium">Lumora</span>
          </div>
          <div className="hidden md:flex items-center gap-9 text-[13px] text-black/60">
            <span className="hover:text-black transition-colors cursor-pointer">Product</span>
            <span className="hover:text-black transition-colors cursor-pointer">Intelligence</span>
            <span className="hover:text-black transition-colors cursor-pointer">Pricing</span>
            <span className="hover:text-black transition-colors cursor-pointer">Customers</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="text-[13px] text-black/70 hover:text-black">Sign in</button>
            <button onClick={onLaunch} className="text-[13px] bg-black text-white px-4 py-2 rounded-full hover:bg-black/85 transition-colors">
              Try the demo →
            </button>
          </div>
        </div>
      </nav>

      <section className="pt-40 pb-32 px-8">
        <div className="max-w-[1400px] mx-auto">
          <div className={mounted ? 'fade-up' : 'opacity-0'} style={{ animationDelay: '0.1s' }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-black/10 bg-black/[0.02] text-[12px] text-black/60 mb-8">
              <span className="w-1.5 h-1.5 rounded-full bg-black" style={{ animation: 'pulse-dot 2s infinite' }} />
              Now in private beta · seed round Q3 2026
            </div>
          </div>
          <h1 className={`max-w-[14ch] text-[clamp(56px,9vw,140px)] leading-[0.92] tracking-[-0.04em] font-medium ${mounted ? 'fade-up' : 'opacity-0'}`} style={{ fontFamily: FONT_DISPLAY, animationDelay: '0.2s' }}>
            The presentation layer for live events.
          </h1>
          <p className={`mt-10 max-w-[52ch] text-[20px] leading-[1.5] text-black/55 ${mounted ? 'fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
            Lumora is the first presentation software that thinks. Built with generative intelligence at its core, it composes slides, translates in real time, and runs your show — across stages, screens, and languages.
          </p>
          <div className={`mt-12 flex flex-wrap items-center gap-4 ${mounted ? 'fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
            <button onClick={onLaunch} className="group flex items-center gap-2 bg-black text-white px-7 py-3.5 rounded-full text-[14px] hover:bg-black/85 transition-all">
              Launch the demo
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
            <button className="flex items-center gap-2 px-7 py-3.5 rounded-full text-[14px] text-black/70 hover:text-black border border-black/10 hover:border-black/30 transition-all">
              Watch the film
              <Play className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
          <div className={`mt-24 grid grid-cols-2 md:grid-cols-4 gap-px bg-black/10 border border-black/10 ${mounted ? 'fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.8s' }}>
            {[
              { k: 'Languages', v: '142' },
              { k: 'Slide composition', v: '<2s' },
              { k: 'Translations / sec', v: '32' },
              { k: 'Beta venues', v: '47' },
            ].map((s) => (
              <div key={s.k} className="bg-white p-8">
                <div className="text-[11px] uppercase tracking-[0.15em] text-black/40 mb-3">{s.k}</div>
                <div className="text-[42px] leading-none tracking-tight" style={{ fontFamily: FONT_DISPLAY }}>{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-8 border-t border-black/5">
        <div className="max-w-[1400px] mx-auto grid md:grid-cols-12 gap-12">
          <div className="md:col-span-4">
            <div className="text-[11px] uppercase tracking-[0.2em] text-black/40 mb-6">01 — The problem</div>
          </div>
          <div className="md:col-span-8">
            <h2 className="text-[clamp(36px,5vw,64px)] leading-[1.05] tracking-[-0.02em] font-medium mb-12" style={{ fontFamily: FONT_DISPLAY }}>
              Every Sunday morning, in every conference center, someone is still typing slides at 11 PM.
            </h2>
            <div className="grid sm:grid-cols-2 gap-8 text-[16px] leading-[1.6] text-black/70">
              <p>ProPresenter was built in 2005. EasyWorship in 2004. The category hasn't been reimagined in two decades. Volunteers waste hours formatting text. Multilingual events stitch together duct-taped workflows.</p>
              <p>Meanwhile, generative models can compose, translate, and adapt content in seconds. The presentation tools have not caught up. Lumora is what they would look like if they were built today.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 px-8 bg-black text-white">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid md:grid-cols-12 gap-12 mb-20">
            <div className="md:col-span-4">
              <div className="text-[11px] uppercase tracking-[0.2em] text-white/40 mb-6">02 — Intelligence</div>
            </div>
            <div className="md:col-span-8">
              <h2 className="text-[clamp(36px,5vw,64px)] leading-[1.05] tracking-[-0.02em] font-medium" style={{ fontFamily: FONT_DISPLAY }}>
                Six capabilities no one else ships.
              </h2>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-px bg-white/10">
            {[
              { icon: Wand2, title: 'Compositional slides', body: 'Paste lyrics, a sermon, or a keynote outline. Lumora composes slides — pacing, line breaks, emphasis — in under two seconds.' },
              { icon: Languages, title: 'Real-time translation', body: 'Side-by-side captions in up to four languages, synchronized with the live slide. Trained on liturgical and event vocabulary.' },
              { icon: Mic, title: 'Voice-following auto-advance', body: 'Lumora listens to the speaker and turns the page when they do. The operator stops being the bottleneck.' },
              { icon: Search, title: 'Semantic verse search', body: 'Type "verses on grief that bring hope." Get the right scripture or quote — not a keyword match, a meaning match.' },
              { icon: ImageIcon, title: 'Generated backgrounds', body: 'Cinematic, on-brand backgrounds composed for the song or message. No more stock loops repeated for ten years.' },
              { icon: Layers, title: 'Show planning copilot', body: 'Describe the service. Lumora drafts the order, picks complementary songs, and lays out the full run-of-show in minutes.' },
            ].map((p, i) => (
              <div key={i} className="bg-black p-10 hover:bg-white/[0.02] transition-colors group">
                <p.icon className="w-5 h-5 text-white/60 mb-8 group-hover:text-white transition-colors" strokeWidth={1.5} />
                <h3 className="text-[22px] leading-tight tracking-[-0.01em] mb-3" style={{ fontFamily: FONT_DISPLAY }}>{p.title}</h3>
                <p className="text-[14px] leading-[1.6] text-white/55">{p.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-8 border-t border-black/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid md:grid-cols-12 gap-12 mb-16">
            <div className="md:col-span-4">
              <div className="text-[11px] uppercase tracking-[0.2em] text-black/40 mb-6">03 — Landscape</div>
            </div>
            <div className="md:col-span-8">
              <h2 className="text-[clamp(36px,5vw,64px)] leading-[1.05] tracking-[-0.02em] font-medium" style={{ fontFamily: FONT_DISPLAY }}>
                The category is large, fragmented, and overdue.
              </h2>
            </div>
          </div>
          <div className="border border-black/10">
            <div className="grid grid-cols-5 text-[12px] uppercase tracking-[0.1em] text-black/50 border-b border-black/10">
              <div className="p-5">Capability</div>
              <div className="p-5 border-l border-black/10">ProPresenter</div>
              <div className="p-5 border-l border-black/10">EasyWorship</div>
              <div className="p-5 border-l border-black/10">OpenLP</div>
              <div className="p-5 border-l border-black/10 bg-black text-white">Lumora</div>
            </div>
            {[
              ['AI slide composition', '—', '—', '—', '✓'],
              ['Live translation', 'Limited', '—', '—', '✓'],
              ['Voice-following', '—', '—', '—', '✓'],
              ['Cloud-native', 'Limited', 'Limited', '—', '✓'],
              ['Semantic search', '—', '—', '—', '✓'],
              ['Pricing', '$399 once', '$15/mo', 'Free', '$19/mo'],
            ].map((row, i) => (
              <div key={i} className="grid grid-cols-5 text-[14px] border-b border-black/5 last:border-b-0">
                <div className="p-5 text-black/80">{row[0]}</div>
                <div className="p-5 border-l border-black/10 text-black/50">{row[1]}</div>
                <div className="p-5 border-l border-black/10 text-black/50">{row[2]}</div>
                <div className="p-5 border-l border-black/10 text-black/50">{row[3]}</div>
                <div className="p-5 border-l border-black/10 bg-black/[0.03] font-medium">{row[4]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 px-8 border-t border-black/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid md:grid-cols-12 gap-12">
            <div className="md:col-span-4">
              <div className="text-[11px] uppercase tracking-[0.2em] text-black/40 mb-6">04 — Market</div>
              <p className="text-[14px] text-black/60 leading-[1.6]">Bottom-up sizing based on Lifeway Research, Faith Communities Today, and ICCA event industry data.</p>
            </div>
            <div className="md:col-span-8 space-y-12">
              {[
                { k: 'TAM', v: '$2.4B', sub: 'Global presentation software for live events, including faith venues and corporate conferences.' },
                { k: 'SAM', v: '$680M', sub: '380K U.S. churches + 600K LATAM faith venues + 90K event organizations with annual budgets.' },
                { k: 'SOM (Year 3)', v: '$24M ARR', sub: 'Capturing 1% of SAM with $19 average MRR — a conservative bottom-up target.' },
              ].map((m) => (
                <div key={m.k} className="grid grid-cols-12 gap-6 items-baseline border-b border-black/10 pb-12">
                  <div className="col-span-2 text-[11px] uppercase tracking-[0.2em] text-black/40">{m.k}</div>
                  <div className="col-span-4 text-[64px] leading-none tracking-tight" style={{ fontFamily: FONT_DISPLAY }}>{m.v}</div>
                  <div className="col-span-6 text-[14px] text-black/60 leading-[1.6]">{m.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 px-8 border-t border-black/5">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid md:grid-cols-12 gap-12 mb-16">
            <div className="md:col-span-4">
              <div className="text-[11px] uppercase tracking-[0.2em] text-black/40 mb-6">05 — Pricing</div>
            </div>
            <div className="md:col-span-8">
              <h2 className="text-[clamp(36px,5vw,64px)] leading-[1.05] tracking-[-0.02em] font-medium" style={{ fontFamily: FONT_DISPLAY }}>Three tiers. No surprises.</h2>
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-px bg-black/10 border border-black/10">
            {[
              { name: 'Solo', price: '0', sub: 'free forever', features: ['Up to 50 songs', 'Basic AI slides', '1 language', 'Single screen', 'Community support'] },
              { name: 'Pro', price: '19', sub: 'per month, billed annually', highlight: true, features: ['Unlimited library', 'All AI features', 'Up to 4 languages live', 'Multi-screen + streaming', 'Cloud sync', 'Priority support'] },
              { name: 'Venue', price: '79', sub: 'per month per location', features: ['Everything in Pro', 'Unlimited team seats', 'Custom branding', 'API access', 'SSO & audit logs', 'Dedicated success'] },
            ].map((tier) => (
              <div key={tier.name} className={`p-10 ${tier.highlight ? 'bg-black text-white' : 'bg-white'}`}>
                <div className="text-[13px] uppercase tracking-[0.15em] mb-6 opacity-60">{tier.name}</div>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-[20px] opacity-60">$</span>
                  <span className="text-[72px] leading-none tracking-tight" style={{ fontFamily: FONT_DISPLAY }}>{tier.price}</span>
                </div>
                <div className="text-[12px] opacity-50 mb-10">{tier.sub}</div>
                <button className={`w-full py-3 text-[13px] rounded-full mb-10 transition-colors ${tier.highlight ? 'bg-white text-black hover:bg-white/90' : 'bg-black text-white hover:bg-black/85'}`}>
                  {tier.price === '0' ? 'Start free' : 'Choose ' + tier.name}
                </button>
                <ul className="space-y-3 text-[14px]">
                  {tier.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <Check className="w-4 h-4 mt-0.5 shrink-0 opacity-60" strokeWidth={1.5} />
                      <span className="opacity-80">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-40 px-8 bg-black text-white">
        <div className="max-w-[1400px] mx-auto text-center">
          <h2 className="text-[clamp(56px,10vw,160px)] leading-[0.9] tracking-[-0.04em] font-medium mb-12" style={{ fontFamily: FONT_DISPLAY }}>
            See what<br/><em>thinking software</em> looks like.
          </h2>
          <button onClick={onLaunch} className="group inline-flex items-center gap-3 bg-white text-black px-10 py-4 rounded-full text-[15px] hover:bg-white/90 transition-all">
            Launch the demo
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <div className="mt-16 text-[12px] uppercase tracking-[0.2em] text-white/40">
            Lumora · Now raising seed · hello@lumora.app
          </div>
        </div>
      </section>

      <footer className="py-12 px-8 border-t border-black/5">
        <div className="max-w-[1400px] mx-auto flex flex-wrap items-center justify-between gap-6 text-[12px] text-black/40">
          <div className="flex items-center gap-2">
            <LumoraMark size={16} />
            <span>Lumora, Inc. · 2026</span>
          </div>
          <span style={{ fontFamily: FONT_MONO }}>v0.4.2-beta</span>
        </div>
      </footer>
    </div>
  );
}

// CONTINÚA EN BLOQUE 2 — pega lo siguiente AL FINAL de este archivo
function AppDemo({ onBack }) {
  const [setlist, setSetlist] = useState([songs[0], songs[2]]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [activeSlide, setActiveSlide] = useState(0);
  const [liveItem, setLiveItem] = useState(null);
  const [liveSlide, setLiveSlide] = useState(0);
  const [isLive, setIsLive] = useState(false);
  const [activePanel, setActivePanel] = useState('library');
  const [languages, setLanguages] = useState(['en', 'es']);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiThinking, setAiThinking] = useState(false);
  const [aiResult, setAiResult] = useState(null);
  const [voiceMode, setVoiceMode] = useState(false);

  const current = setlist[activeIdx];

  const goLive = (slideIdx) => {
    setLiveItem(activeIdx);
    setLiveSlide(slideIdx);
    setIsLive(true);
  };

  useEffect(() => {
    if (!voiceMode || liveItem == null) return;
    const interval = setInterval(() => {
      setLiveSlide((s) => {
        const item = setlist[liveItem];
        if (!item) return s;
        return s < item.slides.length - 1 ? s + 1 : 0;
      });
    }, 3500);
    return () => clearInterval(interval);
  }, [voiceMode, liveItem, setlist]);

  const runAI = (prompt) => {
    setAiThinking(true);
    setAiResult(null);
    setTimeout(() => {
      setAiThinking(false);
      setAiResult({
        prompt,
        slides: [
          { label: 'Generated · Verse', en: ['In the silence I will find You', 'In the waiting I will trust'], es: ['En el silencio Te encontraré', 'En la espera confiaré'], pt: ['No silêncio Te encontrarei', 'Na espera confiarei'], fr: ['Dans le silence je Te trouverai', 'Dans l\'attente je ferai confiance'], ko: ['침묵 속에서 주를 만나리', '기다림 속에 신뢰하리'], zh: ['在寂静中我必寻见你', '在等候中我必信靠'] },
          { label: 'Generated · Bridge', en: ['Even when I cannot see', 'You are working all for me'], es: ['Aún cuando no puedo ver', 'Tú obras todo para mí'], pt: ['Mesmo quando não posso ver', 'Tu obras tudo para mim'], fr: ['Même quand je ne vois pas', 'Tu œuvres tout pour moi'], ko: ['볼 수 없을 때에도', '주는 나를 위해 일하시네'], zh: ['即使我看不见', '你为我成就一切'] },
        ],
        suggestion: 'Composed in 1.8s · Translated to 6 languages · Pairs well with "Way Maker"',
      });
    }, 1800);
  };

  return (
    <div className="h-screen w-full bg-white text-black flex flex-col overflow-hidden" style={{ fontFamily: FONT_BODY }}>
      <div className="h-14 border-b border-black/10 flex items-center px-6 gap-6 shrink-0">
        <button onClick={onBack} className="text-[12px] text-black/50 hover:text-black flex items-center gap-1.5">
          <ChevronRight className="w-3 h-3 rotate-180" /> Back
        </button>
        <div className="h-4 w-px bg-black/10" />
        <div className="flex items-center gap-2">
          <LumoraMark size={18} />
          <span className="text-[14px] font-medium tracking-tight">Lumora</span>
          <span className="text-[10px] uppercase tracking-[0.15em] text-black/40 mt-0.5">Studio</span>
        </div>
        <div className="h-4 w-px bg-black/10" />
        <div className="text-[12px] text-black/50">Sunday Service · April 28</div>
        <div className="flex-1" />
        <LanguagePicker languages={languages} setLanguages={setLanguages} />
        <div className="h-4 w-px bg-black/10" />
        <button
          onClick={() => setVoiceMode(!voiceMode)}
          className={`flex items-center gap-1.5 text-[12px] px-3 py-1.5 rounded-full border transition-all ${voiceMode ? 'bg-black text-white border-black' : 'border-black/15 text-black/70 hover:border-black/40'}`}
        >
          <Mic className="w-3 h-3" />
          {voiceMode ? 'Listening' : 'Voice-follow'}
          {voiceMode && <span className="w-1.5 h-1.5 rounded-full bg-white" style={{ animation: 'pulse-dot 1.2s infinite' }} />}
        </button>
        <button
          onClick={() => setIsLive(!isLive)}
          className={`flex items-center gap-2 text-[12px] px-4 py-1.5 rounded-full transition-all ${isLive ? 'bg-red-600 text-white hover:bg-red-500' : 'bg-black text-white hover:bg-black/85'}`}
        >
          {isLive ? <><span className="w-1.5 h-1.5 rounded-full bg-white" style={{ animation: 'pulse-dot 1.2s infinite' }} />On Air</> : <><Play className="w-3 h-3 fill-current" />Go Live</>}
        </button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-14 border-r border-black/10 flex flex-col items-center py-3 gap-1 shrink-0">
          {[
            { id: 'library', icon: Music },
            { id: 'ai', icon: Sparkles },
            { id: 'bible', icon: BookOpen },
          ].map((p) => {
            const Icon = p.icon;
            const active = activePanel === p.id;
            return (
              <button key={p.id} onClick={() => setActivePanel(p.id)} className={`w-9 h-9 rounded-md flex items-center justify-center transition-colors ${active ? 'bg-black text-white' : 'text-black/50 hover:bg-black/5'}`}>
                <Icon className="w-4 h-4" strokeWidth={1.5} />
              </button>
            );
          })}
        </div>

        <div className="w-72 border-r border-black/10 flex flex-col shrink-0 bg-[#fafafa]">
          {activePanel === 'library' && <LibraryView songs={songs} onAdd={(s) => setSetlist([...setlist, s])} />}
          {activePanel === 'ai' && <AIStudio prompt={aiPrompt} setPrompt={setAiPrompt} onRun={runAI} thinking={aiThinking} result={aiResult} onAddResult={() => { if (aiResult) { setSetlist([...setlist, { id: 'ai-' + Date.now(), title: 'AI Composition', author: 'Lumora Studio', key: '—', slides: aiResult.slides }]); setAiResult(null); } }} />}
          {activePanel === 'bible' && <BibleView onAdd={(s) => setSetlist([...setlist, s])} />}
        </div>

        <div className="w-60 border-r border-black/10 flex flex-col shrink-0">
          <div className="h-10 border-b border-black/10 flex items-center px-4">
            <span className="text-[10px] uppercase tracking-[0.15em] text-black/40">Run of show · {setlist.length}</span>
          </div>
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {setlist.map((it, i) => {
              const isActive = i === activeIdx;
              const isCurrentLive = liveItem === i;
              return (
                <div key={i} onClick={() => { setActiveIdx(i); setActiveSlide(0); }} className={`px-4 py-3 border-b border-black/5 cursor-pointer ${isActive ? 'bg-black text-white' : 'hover:bg-black/[0.02]'}`}>
                  <div className="flex items-start gap-3">
                    <span className={`text-[10px] mt-1 ${isActive ? 'text-white/40' : 'text-black/30'}`} style={{ fontFamily: FONT_MONO }}>{String(i + 1).padStart(2, '0')}</span>
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] leading-tight font-medium truncate">{it.title}</div>
                      <div className={`text-[11px] mt-0.5 ${isActive ? 'text-white/50' : 'text-black/40'}`}>{it.author} · {it.slides.length} slides</div>
                    </div>
                    {isCurrentLive && (
                      <div className="flex items-center gap-1 text-[9px] uppercase tracking-wider text-red-500">
                        <span className="w-1 h-1 rounded-full bg-red-500" style={{ animation: 'pulse-dot 1.2s infinite' }} />Live
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex-1 flex flex-col overflow-hidden bg-[#fafafa] min-w-0">
          <div className="h-10 border-b border-black/10 flex items-center px-5 gap-3 bg-white">
            <span className="text-[14px] font-medium tracking-tight">{current?.title}</span>
            <span className="text-[11px] text-black/40">{current?.author}</span>
            <div className="flex-1" />
            <button className="text-[11px] text-black/50 hover:text-black flex items-center gap-1">
              <Wand2 className="w-3 h-3" /> Re-compose with AI
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
            <div className="grid grid-cols-2 gap-5 max-w-5xl">
              {current?.slides.map((s, i) => {
                const isActive = i === activeSlide;
                const isCurrentLive = liveItem === activeIdx && liveSlide === i;
                return (
                  <button key={i} onClick={() => { setActiveSlide(i); goLive(i); }} className={`group relative aspect-video rounded-lg overflow-hidden border transition-all text-left ${isCurrentLive ? 'border-red-500 shadow-[0_0_0_3px_rgba(239,68,68,0.1)]' : isActive ? 'border-black' : 'border-black/15 hover:border-black/40'}`}>
                    <div className="absolute inset-0 bg-black flex items-center justify-center p-6">
                      <SlideContent slide={s} languages={languages} small />
                    </div>
                    <div className="absolute top-2 left-2 text-[9px] uppercase tracking-[0.1em] text-white/60 px-2 py-0.5 bg-white/10 backdrop-blur-md rounded">{s.label}</div>
                    <div className="absolute bottom-2 right-2 text-[9px] text-white/50" style={{ fontFamily: FONT_MONO }}>{String(i + 1).padStart(2, '0')}</div>
                    {isCurrentLive && (
                      <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] uppercase tracking-wider px-2 py-0.5 bg-red-500 text-white rounded">
                        <span className="w-1 h-1 rounded-full bg-white" style={{ animation: 'pulse-dot 1.2s infinite' }} />Live
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="mt-10 max-w-5xl">
              <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3 flex items-center gap-2">
                <Sparkles className="w-3 h-3" /> Lumora suggestions
              </div>
              <div className="space-y-2">
                {aiSuggestions.map((s, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 bg-white border border-black/10 rounded-md hover:border-black/30 transition-colors cursor-pointer group">
                    <div className="w-1 h-1 rounded-full bg-black mt-2" />
                    <div className="text-[13px] text-black/70 flex-1">{s.text}</div>
                    <button className="text-[11px] text-black/40 group-hover:text-black opacity-0 group-hover:opacity-100 transition-opacity">Apply →</button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="w-80 border-l border-black/10 flex flex-col shrink-0">
          <div className="p-5 border-b border-black/10">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] uppercase tracking-[0.15em] text-black/40 flex items-center gap-1.5">
                <Monitor className="w-3 h-3" /> Live output
              </span>
              <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full flex items-center gap-1.5 ${isLive ? 'bg-red-50 text-red-600' : 'bg-black/5 text-black/50'}`}>
                {isLive ? <span className="w-1 h-1 rounded-full bg-red-500" style={{ animation: 'pulse-dot 1.2s infinite' }} /> : null}
                {isLive ? 'Broadcasting' : 'Standby'}
              </span>
            </div>
            <div className="aspect-video rounded-md overflow-hidden bg-black flex items-center justify-center p-5">
              {liveItem != null && setlist[liveItem] ? (
                <SlideContent slide={setlist[liveItem].slides[liveSlide]} languages={languages} />
              ) : (
                <div className="flex items-center gap-2 opacity-30">
                  <LumoraMark size={20} />
                  <span className="text-white text-[14px] font-medium tracking-tight">Lumora</span>
                </div>
              )}
            </div>
          </div>

          <div className="p-5 border-b border-black/10">
            <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3">Up next</div>
            <div className="aspect-video rounded-md overflow-hidden bg-black/85 flex items-center justify-center p-5 opacity-60">
              {liveItem != null && setlist[liveItem]?.slides[liveSlide + 1] ? (
                <SlideContent slide={setlist[liveItem].slides[liveSlide + 1]} languages={languages} small />
              ) : (
                <span className="text-[10px] text-white/40 uppercase tracking-wider">— end —</span>
              )}
            </div>
          </div>

          <div className="p-5 flex-1 overflow-y-auto scrollbar-thin">
            <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3 flex items-center gap-1.5">
              <Globe className="w-3 h-3" /> Live translation
            </div>
            <div className="space-y-2 mb-6">
              {languages.map(lang => (
                <div key={lang} className="flex items-center justify-between text-[12px] px-3 py-2 bg-black/[0.03] rounded-md border border-black/5">
                  <span className="text-black/70">{LANG_NAMES[lang]}</span>
                  <span className="text-[10px] text-emerald-600 flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-emerald-600" /> Synced
                  </span>
                </div>
              ))}
            </div>
            <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3 flex items-center gap-1.5">
              <Eye className="w-3 h-3" /> Outputs
            </div>
            <div className="space-y-2">
              {[
                { name: 'Main screen', resolution: '3840×2160', active: true },
                { name: 'Stage display', resolution: '1920×1080', active: true },
                { name: 'Live stream', resolution: 'NDI · 1080p', active: isLive },
              ].map(o => (
                <div key={o.name} className="flex items-center justify-between text-[12px] px-3 py-2 bg-white rounded-md border border-black/10">
                  <div>
                    <div className="text-black/80">{o.name}</div>
                    <div className="text-[10px] text-black/40" style={{fontFamily: FONT_MONO}}>{o.resolution}</div>
                  </div>
                  <span className={`w-1.5 h-1.5 rounded-full ${o.active ? 'bg-emerald-500' : 'bg-black/20'}`} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="h-7 border-t border-black/10 flex items-center px-5 gap-5 text-[10px] text-black/40 shrink-0" style={{ fontFamily: FONT_MONO }}>
        <span>LUMORA STUDIO v0.4.2</span>
        <span>·</span>
        <span>SESSION: SUNDAY-2026-04-28</span>
        <span>·</span>
        <span>LATENCY: 12ms</span>
        <div className="flex-1" />
        <span>{setlist.length} ITEMS · {languages.length} LANG · {isLive ? 'BROADCASTING' : 'STANDBY'}</span>
      </div>
    </div>
  );
}

// CONTINÚA EN BLOQUE 3 — pega los componentes auxiliares al final
function LanguagePicker({ languages, setLanguages }) {
  const [open, setOpen] = useState(false);
  const all = ['en', 'es', 'pt', 'fr', 'ko', 'zh'];
  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="flex items-center gap-1.5 text-[12px] px-3 py-1.5 rounded-full border border-black/15 hover:border-black/40 transition-colors">
        <Globe className="w-3 h-3" />
        {languages.length} {languages.length === 1 ? 'language' : 'languages'}
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 w-52 bg-white border border-black/10 rounded-lg shadow-xl p-2 z-50">
          {all.map(l => {
            const on = languages.includes(l);
            return (
              <button key={l} onClick={() => setLanguages(on ? languages.filter(x => x !== l) : [...languages, l])} className="w-full flex items-center justify-between px-3 py-2 text-[13px] hover:bg-black/[0.03] rounded-md">
                <span>{LANG_NAMES[l]}</span>
                {on && <Check className="w-3.5 h-3.5" strokeWidth={2} />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SlideContent({ slide, languages, small }) {
  if (!slide) return null;
  return (
    <div className="text-center text-white w-full" style={{ fontFamily: FONT_DISPLAY }}>
      {languages.map((lang, i) => {
        const lines = slide[lang] || slide.en;
        const isPrimary = i === 0;
        return (
          <div key={lang} className={`${i > 0 ? 'mt-2 pt-2 border-t border-white/10' : ''}`}>
            {lines.map((line, j) => (
              <div key={j} className={`leading-tight tracking-tight ${small ? (isPrimary ? 'text-[11px] font-medium' : 'text-[9px] text-white/60') : (isPrimary ? 'text-[20px] font-medium' : 'text-[12px] text-white/60 mt-0.5')}`}>
                {line}
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

function LibraryView({ songs, onAdd }) {
  const [q, setQ] = useState('');
  const filtered = songs.filter(s => s.title.toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <div className="p-3 border-b border-black/10">
        <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-2">Library</div>
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-black/30" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search songs..." className="w-full bg-white border border-black/10 rounded-md text-[12px] pl-8 pr-2 py-2 focus:outline-none focus:border-black" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {filtered.map(s => (
          <button key={s.id} onClick={() => onAdd(s)} className="w-full text-left px-3 py-2.5 hover:bg-black/[0.03] border-b border-black/5">
            <div className="flex items-start justify-between">
              <div className="min-w-0">
                <div className="text-[13px] font-medium truncate">{s.title}</div>
                <div className="text-[11px] text-black/40 truncate">{s.author}</div>
              </div>
              <span className="text-[10px] text-black/40 px-1.5 py-0.5 bg-black/[0.05] rounded" style={{fontFamily: FONT_MONO}}>{s.key}</span>
            </div>
          </button>
        ))}
      </div>
    </>
  );
}

function AIStudio({ prompt, setPrompt, onRun, thinking, result, onAddResult }) {
  const examples = [
    'Compose a closing prayer slide on grace',
    'Generate a verse and bridge in Hillsong style',
    'Suggest 3 songs that pair with Way Maker',
  ];
  return (
    <>
      <div className="p-4 border-b border-black/10">
        <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3" /> AI Studio
        </div>
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe what you want to compose..." className="w-full bg-white border border-black/10 rounded-md text-[13px] px-3 py-2.5 focus:outline-none focus:border-black resize-none h-24" />
        <button onClick={() => prompt && onRun(prompt)} disabled={!prompt || thinking} className="mt-2 w-full bg-black text-white text-[12px] py-2 rounded-md hover:bg-black/85 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2">
          {thinking ? (<>Composing<span className="thinking-dot">.</span><span className="thinking-dot">.</span><span className="thinking-dot">.</span></>) : (<><Wand2 className="w-3 h-3" /> Compose</>)}
        </button>
      </div>
      {!result && !thinking && (
        <div className="p-4">
          <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-3">Try</div>
          <div className="space-y-1.5">
            {examples.map((e, i) => (
              <button key={i} onClick={() => { setPrompt(e); onRun(e); }} className="w-full text-left text-[12px] text-black/60 hover:text-black p-2.5 bg-white border border-black/10 hover:border-black/30 rounded-md transition-colors">
                {e}
              </button>
            ))}
          </div>
        </div>
      )}
      {thinking && (
        <div className="p-6 flex flex-col items-center justify-center text-center">
          <div className="relative w-12 h-12 mb-4">
            <div className="absolute inset-0 rounded-full border-2 border-black/10" />
            <div className="absolute inset-0 rounded-full border-2 border-black border-r-transparent border-b-transparent animate-spin" />
          </div>
          <div className="text-[12px] text-black/50">Composing</div>
          <div className="text-[10px] text-black/30 mt-1" style={{fontFamily: FONT_MONO}}>~1.8s</div>
        </div>
      )}
      {result && (
        <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
          <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-2">Result</div>
          <div className="text-[12px] text-black/60 mb-4 italic">"{result.prompt}"</div>
          <div className="space-y-2 mb-4">
            {result.slides.map((s, i) => (
              <div key={i} className="bg-black rounded-md p-4 aspect-video flex items-center justify-center">
                <div className="text-center text-white text-[10px] leading-tight" style={{ fontFamily: FONT_DISPLAY }}>
                  {s.en.map((l, j) => <div key={j}>{l}</div>)}
                </div>
              </div>
            ))}
          </div>
          <div className="text-[10px] text-black/40 mb-3" style={{fontFamily: FONT_MONO}}>{result.suggestion}</div>
          <button onClick={onAddResult} className="w-full bg-black text-white text-[12px] py-2 rounded-md hover:bg-black/85 flex items-center justify-center gap-2">
            <Plus className="w-3 h-3" /> Add to run of show
          </button>
        </div>
      )}
    </>
  );
}

function BibleView({ onAdd }) {
  const verses = [
    { ref: 'Psalm 23:1', en: 'The Lord is my shepherd; I shall not want.', es: 'El Señor es mi pastor; nada me faltará.' },
    { ref: 'Philippians 4:13', en: 'I can do all things through Christ who strengthens me.', es: 'Todo lo puedo en Cristo que me fortalece.' },
    { ref: 'John 3:16', en: 'For God so loved the world that he gave his only Son.', es: 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito.' },
    { ref: 'Romans 8:28', en: 'All things work together for good to those who love God.', es: 'Todas las cosas obran para bien de los que aman a Dios.' },
  ];
  const [q, setQ] = useState('');
  return (
    <>
      <div className="p-3 border-b border-black/10">
        <div className="text-[10px] uppercase tracking-[0.15em] text-black/40 mb-2">Scripture</div>
        <div className="relative">
          <Sparkles className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-black/30" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Try: 'verses on hope in trial'" className="w-full bg-white border border-black/10 rounded-md text-[12px] pl-8 pr-2 py-2 focus:outline-none focus:border-black" />
        </div>
        <div className="text-[10px] text-black/40 mt-1.5" style={{fontFamily: FONT_MONO}}>Semantic search · 142 translations</div>
      </div>
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {verses.map((v, i) => (
          <button key={i} onClick={() => onAdd({ id: 'v-' + i + '-' + Date.now(), title: v.ref, author: 'Scripture', key: '—', slides: [{ label: v.ref, en: [v.en], es: [v.es], pt: [v.es], fr: [v.en], ko: [v.en], zh: [v.en] }] })} className="w-full text-left p-3 hover:bg-black/[0.03] border-b border-black/5">
            <div className="text-[10px] uppercase tracking-[0.1em] text-black/40 mb-1" style={{fontFamily: FONT_MONO}}>{v.ref}</div>
            <div className="text-[12px] text-black/80 leading-snug">{v.en}</div>
          </button>
        ))}
      </div>
    </>
  );
}