/**
 * Lumen Live — AI API Server
 *
 * Proxies all AI requests to OpenAI so the OPENAI_API_KEY is never
 * exposed to the browser. The React frontend calls /api/ai only.
 *
 * OPENAI_API_KEY is read exclusively here — never sent to the client.
 */

import express from 'express';
import cors from 'cors';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Load .env from project root if running standalone
const __dir = dirname(fileURLToPath(import.meta.url));
try {
  const envPath = join(__dir, '.env');
  const envText = readFileSync(envPath, 'utf8');
  for (const line of envText.split('\n')) {
    const m = line.match(/^([A-Z_][A-Z0-9_]*)=(.*)$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch {}

// OPENAI_API_KEY is used only in this file — never forwarded to client responses
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const MODEL = 'gpt-4o-mini'; // best low-cost OpenAI model

const app = express();
app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

// ─── OpenAI Responses API helper ────────────────────────────────────────────
// Uses the newer /v1/responses endpoint with structured JSON output support.
// Falls back to a plain text response when JSON schema isn't needed.
async function callOpenAI({ systemPrompt, userMessage, jsonSchema = null, maxTokens = 1000, temperature = 0.7 }) {
  if (!OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not set on the server.');

  const body = {
    model: MODEL,
    temperature,
    max_output_tokens: maxTokens,
    input: [
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: userMessage  },
    ],
  };

  // Attach JSON schema if structured output is requested
  if (jsonSchema) {
    body.text = {
      format: {
        type: 'json_schema',
        name: jsonSchema.name,
        schema: jsonSchema.schema,
        strict: true,
      },
    };
  }

  const res = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // OPENAI_API_KEY is only used here, server-side
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || `OpenAI error ${res.status}`);
  }

  const data = await res.json();
  // Responses API returns output_text in data.output[0].content[0].text
  const text = data.output?.[0]?.content?.[0]?.text ?? '';
  return text.trim();
}

// ─── Route: POST /api/ai ─────────────────────────────────────────────────────
// Single unified endpoint. Client sends { action, payload }.
app.post('/api/ai', async (req, res) => {
  const { action, payload } = req.body ?? {};

  if (!action) {
    return res.status(400).json({ error: 'Missing action.' });
  }
  if (!OPENAI_API_KEY) {
    return res.status(500).json({ error: 'OPENAI_API_KEY is not configured on the server.' });
  }

  try {
    let result;

    switch (action) {

      // ── 1. Split lyrics into slides ─────────────────────────────────────────
      case 'splitLyrics': {
        const { lyrics } = payload ?? {};
        if (!lyrics?.trim()) return res.status(400).json({ error: 'lyrics is required.' });

        const text = await callOpenAI({
          systemPrompt: `You are a worship presentation assistant. Split the worship song lyrics into slides.
Rules:
- Each slide: 2–4 lines maximum
- Identify and label: Verso 1, Verso 2, Coro, Puente, Intro, Outro
- Repeated sections must share the same label (both choruses = "Coro")
- Keep original line breaks within each slide
Return ONLY valid JSON matching the schema — no markdown, no extra text.`,
          userMessage: lyrics,
          temperature: 0.2,
          maxTokens: 1200,
          jsonSchema: {
            name: 'slides',
            schema: {
              type: 'object',
              properties: {
                slides: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      label:  { type: 'string' },
                      lyrics: { type: 'string' },
                    },
                    required: ['label', 'lyrics'],
                    additionalProperties: false,
                  },
                },
              },
              required: ['slides'],
              additionalProperties: false,
            },
          },
        });

        const parsed = JSON.parse(text);
        result = { slides: parsed.slides };
        break;
      }

      // ── 2. Translate lyrics ─────────────────────────────────────────────────
      case 'translateLyrics': {
        const { lyrics, targetLang } = payload ?? {};
        if (!lyrics?.trim())    return res.status(400).json({ error: 'lyrics is required.' });
        if (!targetLang?.trim()) return res.status(400).json({ error: 'targetLang is required.' });

        const text = await callOpenAI({
          systemPrompt: `You are a worship lyrics translator. Translate the worship song lyrics to ${targetLang}.
Rules:
- Keep the poetic and devotional style
- Preserve all line breaks exactly
- Return only the translated lyrics — no explanations, no headers`,
          userMessage: lyrics,
          temperature: 0.4,
          maxTokens: 1000,
        });

        result = { translation: text };
        break;
      }

      // ── 3. Sermon outline ───────────────────────────────────────────────────
      case 'sermonOutline': {
        const { topic } = payload ?? {};
        if (!topic?.trim()) return res.status(400).json({ error: 'topic is required.' });

        const text = await callOpenAI({
          systemPrompt: `You are a pastor's assistant. Generate a detailed sermon outline in Spanish.
Include:
- Sermon title
- Primary scripture reference
- Introduction with hook/illustration
- 3 main points (Roman numerals), each with 2 sub-points and a practical application
- Conclusion with call to action
- Closing prayer prompt
- 3 additional study verses
Format clearly with headers. Write in Spanish.`,
          userMessage: `Topic: ${topic}`,
          temperature: 0.7,
          maxTokens: 1200,
        });

        result = { outline: text };
        break;
      }

      // ── 4. Background image suggestions ─────────────────────────────────────
      case 'suggestBackgrounds': {
        const { input } = payload ?? {};
        if (!input?.trim()) return res.status(400).json({ error: 'input is required.' });

        const text = await callOpenAI({
          systemPrompt: `You are a visual worship designer. Given a song title or worship theme, suggest 5 Pexels search queries for projection backgrounds.
Rules:
- Each query: 2–4 words, cinematic, evocative, appropriate for church worship
- Vary the mood (light, dark, nature, abstract, architectural)
- Avoid people or faces — focus on landscapes, light, textures
Return ONLY valid JSON matching the schema.`,
          userMessage: input,
          temperature: 0.8,
          maxTokens: 150,
          jsonSchema: {
            name: 'backgrounds',
            schema: {
              type: 'object',
              properties: {
                queries: {
                  type: 'array',
                  items: { type: 'string' },
                },
              },
              required: ['queries'],
              additionalProperties: false,
            },
          },
        });

        const parsed = JSON.parse(text);
        result = { queries: parsed.queries };
        break;
      }

      // ── 5. Lower-third livestream text ──────────────────────────────────────
      case 'lowerThirds': {
        const { context } = payload ?? {};
        if (!context?.trim()) return res.status(400).json({ error: 'context is required.' });

        const text = await callOpenAI({
          systemPrompt: `Generate lower-third text for a church livestream in Spanish.
Rules:
- Each item under 55 characters
- Warm, welcoming tone
- Vary format: name + title, event info, website, follow CTA
Return ONLY valid JSON matching the schema.`,
          userMessage: context,
          temperature: 0.6,
          maxTokens: 250,
          jsonSchema: {
            name: 'lower_thirds',
            schema: {
              type: 'object',
              properties: {
                items: {
                  type: 'array',
                  items: { type: 'string' },
                },
              },
              required: ['items'],
              additionalProperties: false,
            },
          },
        });

        const parsed = JSON.parse(text);
        result = { items: parsed.items };
        break;
      }

      // ── 6. Church announcement ──────────────────────────────────────────────
      case 'announcement': {
        const { brief } = payload ?? {};
        if (!brief?.trim()) return res.status(400).json({ error: 'brief is required.' });

        const text = await callOpenAI({
          systemPrompt: `Write a short, warm church announcement in Spanish.
Rules:
- Under 70 words total
- Inviting, clear, and encouraging tone
- Include the key information from the brief
- End with a simple call to action
Return only the announcement text — no quotes, no markdown.`,
          userMessage: brief,
          temperature: 0.7,
          maxTokens: 200,
        });

        result = { announcement: text };
        break;
      }

      // ── 7. Verse to sermon points ───────────────────────────────────────────
      case 'verseToPoints': {
        const { verse } = payload ?? {};
        if (!verse?.trim()) return res.status(400).json({ error: 'verse is required.' });

        const text = await callOpenAI({
          systemPrompt: `You are a pastor's assistant. Given a Bible verse or passage, generate exactly 3 sermon points in Spanish.
Format each point as:
[number]. [TITLE IN CAPS]
   [1–2 sentences of explanation and application]

Return only the 3 formatted sermon points — no intro, no summary.`,
          userMessage: verse,
          temperature: 0.7,
          maxTokens: 500,
        });

        result = { points: text };
        break;
      }

      default:
        return res.status(400).json({ error: `Unknown action: ${action}` });
    }

    res.json({ ok: true, ...result });

  } catch (err) {
    console.error(`[/api/ai] ${action} error:`, err.message);
    res.status(500).json({ error: err.message || 'Internal server error.' });
  }
});

// ─── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, openai: !!OPENAI_API_KEY });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Lumen AI server running on http://localhost:${PORT}`);
  if (!OPENAI_API_KEY) {
    console.warn('⚠  OPENAI_API_KEY is not set — AI endpoints will return errors.');
  }
});
