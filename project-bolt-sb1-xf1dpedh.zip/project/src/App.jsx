import React, {
  useState, useMemo, useEffect, useCallback, useRef,
} from 'react';
import {
  Music, BookOpen, Image as ImageIcon, Search, Plus, Play, Pause,
  Circle, GripVertical, Palette, Maximize2, X, FolderOpen,
  CreditCard as Edit3, Copy, Trash2, Download, CircleAlert as AlertCircle,
  Monitor, Sparkles, Timer, LayoutGrid, ChevronLeft, ChevronRight,
  Square, Eye, Mic,
} from 'lucide-react';
import {
  loadState, saveState, getDefaultState, defaultThemes, uid,
  writeLiveState, respondToStateRequests,
} from './store';
import SongModal       from './components/SongModal';
import SlideEditModal  from './components/SlideEditModal';
import SlideGrid       from './components/SlideGrid';
import LiveOutput      from './components/LiveOutput';
import BiblePanel      from './components/BiblePanel';
import MediaPanel      from './components/MediaPanel';
import AiStudio        from './components/AiStudio';
import ScreensPanel    from './components/ScreensPanel';

// ─── Confirm dialog ────────────────────────────────────────────────────────────
function ConfirmDialog({ message, onConfirm, onCancel }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 backdrop-blur-sm">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
        <div className="flex items-start gap-3 mb-5">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-sm text-zinc-200">{message}</p>
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={onCancel}  className="text-sm px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors">Cancelar</button>
          <button onClick={onConfirm} className="text-sm px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white transition-colors">Eliminar</button>
        </div>
      </div>
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  // ── Restore persisted state once on mount ────────────────────────────────────
  const _saved = loadState() ?? getDefaultState();
  const _def   = getDefaultState();

  // ── Persisted state ──────────────────────────────────────────────────────────
  const [songs,         setSongs]         = useState(() => _saved.songs         ?? _def.songs);
  const [setlist,       setSetlist]       = useState(() => _saved.setlist       ?? _def.setlist);
  const [activeThemeId, setActiveThemeId] = useState(() => _saved.activeThemeId ?? _def.activeThemeId);
  const [mediaLibrary,  setMediaLibrary]  = useState(() => _saved.mediaLibrary  ?? _def.mediaLibrary);
  const [autoplayInterval, setAutoplayInterval] = useState(() => _saved.autoplayInterval ?? _def.autoplayInterval);

  // Restore serviceStartMs only if the saved session is < 24 h old (otherwise stale)
  const [serviceStartMs, setServiceStartMs] = useState(() => {
    const ms = _saved.serviceStartMs;
    if (ms && Date.now() - ms < 24 * 60 * 60 * 1000) return ms;
    return null;
  });

  // ── UI state (persisted) ─────────────────────────────────────────────────────
  const [activeLibTab,     setActiveLibTab]     = useState(() => _saved.activeLibTab     ?? _def.activeLibTab);
  const [activeSetlistIdx, setActiveSetlistIdx] = useState(() => {
    const idx = _saved.activeSetlistIdx ?? 0;
    const safeIdx = (_saved.setlist ?? _def.setlist).length > 0 ? Math.min(idx, (_saved.setlist ?? _def.setlist).length - 1) : 0;
    return safeIdx;
  });
  const [activeSlideIdx, setActiveSlideIdx] = useState(() => {
    const item = (_saved.setlist ?? _def.setlist)[_saved.activeSetlistIdx ?? 0];
    const idx  = _saved.activeSlideIdx ?? 0;
    return item ? Math.min(idx, item.slides.length - 1) : 0;
  });

  // ── UI state (session-only) ──────────────────────────────────────────────────
  const [search,           setSearch]           = useState('');

  // Live state (session-only — operator starts live intentionally each session)
  const [isLive,         setIsLive]         = useState(false);
  const [outputMode,     setOutputMode]     = useState('logo');
  const [liveSetlistIdx, setLiveSetlistIdx] = useState(null);
  const [liveSlideIdx,   setLiveSlideIdx]   = useState(null);
  const [liveMedia,      setLiveMedia]      = useState(null);
  const [bgMedia,        setBgMedia]        = useState(null);
  const [isFrozen,       setIsFrozen]       = useState(false);
  const [autoplay,       setAutoplay]       = useState(false);

  // Timers
  const [countdownEndsAt, setCountdownEndsAt] = useState(null);

  // Modals / dialogs
  const [songModal,     setSongModal]     = useState(null);
  const [editingSlide,  setEditingSlide]  = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  // ── Derived ──────────────────────────────────────────────────────────────────
  const theme = defaultThemes.find(t => t.id === activeThemeId) ?? defaultThemes[1];

  const filteredSongs = useMemo(() => {
    const q = search.toLowerCase();
    return songs.filter(s =>
      s.title.toLowerCase().includes(q) ||
      (s.author   || '').toLowerCase().includes(q) ||
      (s.category || '').toLowerCase().includes(q)
    );
  }, [songs, search]);

  const currentItem = setlist[activeSetlistIdx] ?? null;
  const liveItem    = liveSetlistIdx != null ? setlist[liveSetlistIdx] : null;
  const liveSlide   = liveItem?.slides[liveSlideIdx] ?? null;

  const nextSlide = useMemo(() => {
    if (!liveItem || liveSlideIdx == null) return null;
    if (liveSlideIdx < liveItem.slides.length - 1) return liveItem.slides[liveSlideIdx + 1];
    return setlist[liveSetlistIdx + 1]?.slides[0] ?? null;
  }, [liveItem, liveSlideIdx, liveSetlistIdx, setlist]);

  // ── Persistence — auto-save every relevant change ────────────────────────────
  useEffect(() => {
    saveState({
      songs,
      setlist,
      activeThemeId,
      activeLibTab,
      activeSetlistIdx,
      activeSlideIdx,
      autoplayInterval,
      serviceStartMs,
      mediaLibrary,
    });
  }, [songs, setlist, activeThemeId, activeLibTab, activeSetlistIdx,
      activeSlideIdx, autoplayInterval, serviceStartMs, mediaLibrary]);

  // ── Cross-tab live sync ───────────────────────────────────────────────────────
  useEffect(() => {
    writeLiveState({
      isLive,
      outputMode,
      slide:        liveSlide,
      nextSlide,
      themeId:      activeThemeId,
      title:        liveItem?.title,
      label:        liveSlide?.label,
      slideNum:     (liveSlideIdx ?? 0) + 1,
      totalSlides:  liveItem?.slides.length ?? 0,
      media:        liveMedia,
      bgMedia,
      serviceStartMs,
      countdownEndsAt,
      isFrozen,
    });
  }, [isLive, outputMode, liveSlide, nextSlide, activeThemeId, liveItem,
      liveSlideIdx, liveMedia, bgMedia, serviceStartMs, countdownEndsAt, isFrozen]);

  // ── Respond to screen tabs requesting current state on mount ─────────────────
  // When a /live, /stage, or /confidence tab opens, it sends REQUEST_STATE.
  // This effect listens and re-broadcasts the current live state immediately.
  useEffect(() => {
    const liveState = {
      isLive, outputMode, slide: liveSlide, nextSlide,
      themeId: activeThemeId, title: liveItem?.title,
      label: liveSlide?.label,
      slideNum: (liveSlideIdx ?? 0) + 1,
      totalSlides: liveItem?.slides.length ?? 0,
      media: liveMedia, bgMedia, serviceStartMs, countdownEndsAt, isFrozen,
    };
    const unsub = respondToStateRequests(() => liveState);
    return unsub;
  }, [isLive, outputMode, liveSlide, nextSlide, activeThemeId, liveItem,
      liveSlideIdx, liveMedia, bgMedia, serviceStartMs, countdownEndsAt, isFrozen]);

  // ── Autoplay timer ────────────────────────────────────────────────────────────
  const goNextSlideRef = useRef(null);
  useEffect(() => {
    if (!autoplay || !isLive) return;
    const id = setInterval(() => goNextSlideRef.current?.(), (autoplayInterval ?? 5) * 1000);
    return () => clearInterval(id);
  }, [autoplay, isLive, autoplayInterval]);

  // ── Live helpers ──────────────────────────────────────────────────────────────
  const stopLive = useCallback(() => {
    setIsLive(false);
    setOutputMode('logo');
    setLiveSetlistIdx(null);
    setLiveSlideIdx(null);
    setAutoplay(false);
    setIsFrozen(false);
  }, []);

  const startLive = useCallback((setlistIdx, slideIdx) => {
    setLiveSetlistIdx(setlistIdx);
    setLiveSlideIdx(slideIdx);
    setOutputMode('slide');
    setIsLive(true);
  }, []);

  const goNextSlide = useCallback(() => {
    if (!liveItem) return;
    if (liveSlideIdx < liveItem.slides.length - 1) {
      setLiveSlideIdx(n => n + 1);
    } else if (liveSetlistIdx < setlist.length - 1) {
      const next = liveSetlistIdx + 1;
      setLiveSetlistIdx(next);
      setLiveSlideIdx(0);
      setActiveSetlistIdx(next);
      setActiveSlideIdx(0);
    }
  }, [liveItem, liveSlideIdx, liveSetlistIdx, setlist]);

  // Keep ref current so the autoplay interval always calls the latest version
  useEffect(() => { goNextSlideRef.current = goNextSlide; }, [goNextSlide]);

  const goPrevSlide = useCallback(() => {
    if (liveSlideIdx > 0) {
      setLiveSlideIdx(n => n - 1);
    } else if (liveSetlistIdx > 0) {
      const prev = liveSetlistIdx - 1;
      setLiveSetlistIdx(prev);
      setLiveSlideIdx(setlist[prev].slides.length - 1);
      setActiveSetlistIdx(prev);
      setActiveSlideIdx(setlist[prev].slides.length - 1);
    }
  }, [liveSlideIdx, liveSetlistIdx, setlist]);

  // ── Keyboard shortcuts ────────────────────────────────────────────────────────
  useEffect(() => {
    function handle(e) {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); if (isLive) goNextSlide(); }
      if (e.key === 'ArrowLeft')  { e.preventDefault(); if (isLive) goPrevSlide(); }
      if (e.key === 'b' || e.key === 'B') setOutputMode(m => m === 'black' ? 'slide' : 'black');
      if (e.key === 'l' || e.key === 'L') setOutputMode('logo');
      if (e.key === 'c' || e.key === 'C') setOutputMode('clear');
      if (e.key === 'f' || e.key === 'F') setIsFrozen(f => !f);
      if (e.key === 'Escape') stopLive();
    }
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  }, [isLive, goNextSlide, goPrevSlide, stopLive]);

  // ── Slide click → push live ───────────────────────────────────────────────────
  function handleSlideClick(slideIdx) {
    setActiveSlideIdx(slideIdx);
    startLive(activeSetlistIdx, slideIdx);
  }

  // ── Setlist ───────────────────────────────────────────────────────────────────
  const addToSetlist = useCallback((item) => {
    setSetlist(prev => [...prev, { ...item, id: item.id + '-' + uid() }]);
  }, []);

  function removeFromSetlist(i) {
    setSetlist(prev => {
      const next = prev.filter((_, idx) => idx !== i);
      setActiveSetlistIdx(a => Math.min(a, Math.max(0, next.length - 1)));
      if (liveSetlistIdx === i) stopLive();
      return next;
    });
  }

  const dragIdx = useRef(null);
  function onDrop(i) {
    const from = dragIdx.current;
    if (from == null || from === i) return;
    setSetlist(prev => {
      const next = [...prev];
      const [moved] = next.splice(from, 1);
      next.splice(i, 0, moved);
      return next;
    });
    if (activeSetlistIdx === from) setActiveSetlistIdx(i);
    dragIdx.current = null;
  }

  // ── Song CRUD ─────────────────────────────────────────────────────────────────
  function saveSong(songData) {
    setSongs(prev => {
      const idx = prev.findIndex(s => s.id === songData.id);
      return idx === -1 ? [...prev, songData] : prev.map(s => s.id === songData.id ? songData : s);
    });
    setSetlist(prev => prev.map(item =>
      (item._songId || item.id.split('-')[0]) === songData.id
        ? { ...songData, id: item.id, _songId: songData.id }
        : item
    ));
    setSongModal(null);
  }

  function deleteSong(id) {
    setSongs(prev => prev.filter(s => s.id !== id));
    setSetlist(prev => prev.filter(item => (item._songId || item.id.split('-')[0]) !== id));
    setConfirmDelete(null);
  }

  function duplicateSong(song) {
    setSongs(prev => [...prev, {
      ...song, id: uid(), title: song.title + ' (copia)',
      slides: song.slides.map(s => ({ ...s, id: uid() })),
    }]);
  }

  // ── Slide CRUD on setlist item ────────────────────────────────────────────────
  function updateSetlistSlide(setlistIdx, slideIdx, newSlide) {
    setSetlist(prev => prev.map((item, i) =>
      i !== setlistIdx ? item : { ...item, slides: item.slides.map((s, j) => j === slideIdx ? newSlide : s) }
    ));
    setEditingSlide(null);
  }

  function addSlide() {
    setSetlist(prev => prev.map((item, i) =>
      i !== activeSetlistIdx ? item : { ...item, slides: [...item.slides, { id: uid(), label: 'Nuevo', title: '', lyrics: '' }] }
    ));
  }

  function deleteSlide(slideIdx) {
    setSetlist(prev => prev.map((item, i) => {
      if (i !== activeSetlistIdx) return item;
      const next = item.slides.filter((_, j) => j !== slideIdx);
      return { ...item, slides: next.length ? next : [{ id: uid(), label: 'Slide', title: '', lyrics: '' }] };
    }));
  }

  function moveSlide(slideIdx, dir) {
    const j = slideIdx + dir;
    setSetlist(prev => prev.map((item, i) => {
      if (i !== activeSetlistIdx || j < 0 || j >= item.slides.length) return item;
      const next = [...item.slides];
      [next[slideIdx], next[j]] = [next[j], next[slideIdx]];
      return { ...item, slides: next };
    }));
  }

  // ── Export / Import ───────────────────────────────────────────────────────────
  function exportService() {
    const blob = new Blob([JSON.stringify({ songs, setlist, activeThemeId, version: 3 }, null, 2)], { type: 'application/json' });
    const a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(blob),
      download: `lumen-${new Date().toISOString().slice(0, 10)}.json`,
    });
    a.click(); URL.revokeObjectURL(a.href);
  }
  const importRef = useRef();
  function importService(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const d = JSON.parse(ev.target.result);
        if (d.songs)         setSongs(d.songs);
        if (d.setlist)       setSetlist(d.setlist);
        if (d.activeThemeId) setActiveThemeId(d.activeThemeId);
      } catch { alert('Archivo no válido.'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  // ── Media → live ──────────────────────────────────────────────────────────────
  function sendMediaToLive(item) {
    setLiveMedia(item); setOutputMode('media'); setIsLive(true);
  }

  function setLiveBgMedia(item) {
    setBgMedia(item);
    // If not already live, switch to slide mode so the background is visible with lyrics
    if (!isLive) {
      setOutputMode('slide');
    }
  }

  // ── Library tabs ──────────────────────────────────────────────────────────────
  const LIB_TABS = [
    { id: 'songs',   label: 'Cantos',   Icon: Music      },
    { id: 'bible',   label: 'Biblia',   Icon: BookOpen   },
    { id: 'media',   label: 'Media',    Icon: ImageIcon  },
    { id: 'ai',      label: 'AI',       Icon: Sparkles   },
    { id: 'screens', label: 'Pantallas',Icon: Monitor    },
  ];

  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <div className="h-screen w-screen bg-zinc-950 text-zinc-100 flex flex-col overflow-hidden select-none">

      {/* ══ TOP BAR ══════════════════════════════════════════════════════════════ */}
      <header className="h-11 shrink-0 bg-zinc-900 border-b border-zinc-800 flex items-center px-3 gap-1.5">
        {/* Logo */}
        <div className="flex items-center gap-2 mr-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center shrink-0">
            <Circle className="w-3 h-3 text-zinc-950 fill-zinc-950" />
          </div>
          <span className="font-serif text-base text-zinc-100 leading-none">Lumen</span>
          <span className="text-[9px] uppercase tracking-[0.2em] text-amber-500/70 leading-none mt-0.5">Live</span>
        </div>

        <div className="w-px h-5 bg-zinc-800 mx-0.5" />

        <button onClick={exportService}
          className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-100 px-2 py-1 rounded-md hover:bg-zinc-800 transition-colors">
          <Download className="w-3.5 h-3.5" /> Exportar
        </button>
        <button onClick={() => importRef.current?.click()}
          className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-100 px-2 py-1 rounded-md hover:bg-zinc-800 transition-colors">
          <FolderOpen className="w-3.5 h-3.5" /> Importar
        </button>
        <input ref={importRef} type="file" accept=".json" className="hidden" onChange={importService} />

        <div className="flex-1" />

        {/* Theme dots */}
        <div className="flex items-center gap-1 mr-1">
          {defaultThemes.map(t => (
            <button key={t.id} onClick={() => setActiveThemeId(t.id)} title={t.name}
              className={`w-4 h-4 rounded-full border-2 transition-all ${activeThemeId === t.id ? 'border-amber-400 scale-125' : 'border-zinc-700 hover:border-zinc-500'}`}
              style={{ background: t.preview }} />
          ))}
        </div>

        <div className="w-px h-5 bg-zinc-800 mx-1" />

        {/* Output mode buttons */}
        <div className="flex items-center gap-0.5">
          <button onClick={() => setOutputMode('black')}
            className={`text-[11px] px-2 py-1 rounded transition-colors ${outputMode === 'black' ? 'bg-zinc-200 text-zinc-900 font-semibold' : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'}`}
            title="Negro (B)">
            <Square className="w-3 h-3 fill-current inline mr-1" />Negro
          </button>
          <button onClick={() => setOutputMode('logo')}
            className={`text-[11px] px-2 py-1 rounded transition-colors ${outputMode === 'logo' ? 'bg-amber-600 text-white font-semibold' : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'}`}
            title="Logo (L)">
            Logo
          </button>
          <button onClick={() => setOutputMode('clear')}
            className={`text-[11px] px-2 py-1 rounded transition-colors ${outputMode === 'clear' ? 'bg-zinc-600 text-white font-semibold' : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'}`}
            title="Limpiar (C)">
            Limpiar
          </button>
        </div>

        <div className="w-px h-5 bg-zinc-800 mx-1" />

        {/* Prev / Next */}
        <div className="flex items-center gap-0.5">
          <button onClick={goPrevSlide} disabled={!isLive}
            className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-zinc-300 transition-colors" title="Anterior (←)">
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button onClick={goNextSlide} disabled={!isLive}
            className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-zinc-300 transition-colors" title="Siguiente (→)">
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="w-px h-5 bg-zinc-800 mx-1" />

        {/* Go Live */}
        <button
          onClick={isLive ? stopLive : () => startLive(activeSetlistIdx, activeSlideIdx)}
          className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-semibold transition-all ${
            isLive
              ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_12px_rgba(239,68,68,0.3)]'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}>
          {isLive
            ? <><Pause className="w-3.5 h-3.5" /> En Vivo</>
            : <><Play  className="w-3.5 h-3.5 fill-current" /> Iniciar</>}
        </button>
      </header>

      {/* ══ MAIN CONTENT ═════════════════════════════════════════════════════════ */}
      <div className="flex-1 flex overflow-hidden min-h-0">

        {/* ── LIBRARY SIDEBAR ────────────────────────────────────────────────── */}
        <aside className="w-64 shrink-0 bg-zinc-900 border-r border-zinc-800 flex flex-col overflow-hidden">

          {/* Tab bar */}
          <div className="flex border-b border-zinc-800 shrink-0 overflow-x-auto">
            {LIB_TABS.map(({ id, label, Icon }) => (
              <button key={id} onClick={() => setActiveLibTab(id)}
                className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[9px] uppercase tracking-wide transition-colors whitespace-nowrap min-w-0 ${
                  activeLibTab === id
                    ? 'text-amber-400 border-b-2 border-amber-500 bg-zinc-800/50'
                    : 'text-zinc-600 hover:text-zinc-400 border-b-2 border-transparent'
                }`}>
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate w-full text-center px-0.5">{label}</span>
              </button>
            ))}
          </div>

          {/* Songs tab */}
          {activeLibTab === 'songs' && (
            <>
              <div className="p-2 border-b border-zinc-800 flex gap-1.5 shrink-0">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-600" />
                  <input value={search} onChange={e => setSearch(e.target.value)}
                    placeholder="Buscar cantos…"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-lg text-xs pl-7 pr-2 py-1.5 text-zinc-200 focus:outline-none focus:border-amber-600 transition-colors" />
                </div>
                <button onClick={() => setSongModal({ song: null })}
                  className="p-1.5 bg-amber-600 hover:bg-amber-500 rounded-lg text-white transition-colors" title="Nuevo canto">
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto min-h-0">
                {filteredSongs.length === 0
                  ? <div className="flex flex-col items-center justify-center py-12 text-zinc-700 gap-2"><Music className="w-8 h-8" /><span className="text-xs">Sin cantos</span></div>
                  : filteredSongs.map(song => (
                    <div key={song.id}
                      className="group flex items-start gap-1 px-2 py-2.5 hover:bg-zinc-800/50 border-b border-zinc-800/50 transition-colors">
                      <button className="flex-1 text-left min-w-0" onClick={() => addToSetlist(song)}>
                        <div className="text-xs font-medium text-zinc-100 truncate">{song.title}</div>
                        <div className="text-[10px] text-zinc-500 truncate mt-0.5">
                          {song.author}
                          {song.category && <span className="text-zinc-700"> · {song.category}</span>}
                        </div>
                        <div className="text-[9px] text-zinc-700 mt-0.5">{song.slides?.length} slides</div>
                      </button>
                      <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 pt-0.5">
                        <button onClick={() => setSongModal({ song })} title="Editar"
                          className="p-1 hover:bg-zinc-700 rounded text-zinc-500 hover:text-zinc-100 transition-colors"><Edit3 className="w-3 h-3" /></button>
                        <button onClick={() => duplicateSong(song)} title="Duplicar"
                          className="p-1 hover:bg-zinc-700 rounded text-zinc-500 hover:text-zinc-100 transition-colors"><Copy className="w-3 h-3" /></button>
                        <button onClick={() => setConfirmDelete({ type: 'song', id: song.id, message: `¿Eliminar "${song.title}"?` })}
                          className="p-1 hover:bg-zinc-700 rounded text-zinc-500 hover:text-red-400 transition-colors"><Trash2 className="w-3 h-3" /></button>
                      </div>
                    </div>
                  ))
                }
              </div>
            </>
          )}

          {activeLibTab === 'bible'   && <BiblePanel onAddToSetlist={addToSetlist} />}
          {activeLibTab === 'media'   && (
            <MediaPanel
              mediaLibrary={mediaLibrary}
              setMediaLibrary={setMediaLibrary}
              onSendToLive={sendMediaToLive}
              bgMedia={bgMedia}
              onSetBgMedia={setLiveBgMedia}
              onClearBgMedia={() => setBgMedia(null)}
            />
          )}
          {activeLibTab === 'ai'      && <AiStudio onAddToSetlist={addToSetlist} />}
          {activeLibTab === 'screens' && (
            <ScreensPanel
              serviceStartMs={serviceStartMs}
              setServiceStartMs={setServiceStartMs}
              countdownEndsAt={countdownEndsAt}
              setCountdownEndsAt={setCountdownEndsAt}
            />
          )}
        </aside>

        {/* ── SETLIST PANEL ──────────────────────────────────────────────────── */}
        <div className="w-52 shrink-0 bg-[#111113] border-r border-zinc-800 flex flex-col overflow-hidden">
          <div className="h-9 border-b border-zinc-800 flex items-center px-3 shrink-0">
            <span className="text-[10px] uppercase tracking-wider text-zinc-500">
              Servicio {setlist.length > 0 && `· ${setlist.length}`}
            </span>
          </div>
          <div className="flex-1 overflow-y-auto min-h-0">
            {setlist.length === 0
              ? (
                <div className="flex flex-col items-center justify-center py-10 gap-2 text-zinc-700">
                  <Maximize2 className="w-7 h-7" />
                  <div className="text-xs text-center px-4">Haz clic en un canto para agregar</div>
                </div>
              )
              : setlist.map((item, i) => {
                const isActive  = i === activeSetlistIdx;
                const isLiveRow = liveSetlistIdx === i && isLive;
                return (
                  <div key={`${item.id}-${i}`}
                    draggable
                    onDragStart={() => { dragIdx.current = i; }}
                    onDragOver={e => e.preventDefault()}
                    onDrop={() => onDrop(i)}
                    onClick={() => { setActiveSetlistIdx(i); setActiveSlideIdx(0); }}
                    className={`group flex items-center gap-2 px-2 py-2 border-b border-zinc-800/40 cursor-pointer transition-colors ${
                      isActive ? 'bg-amber-950/25 border-l-2 border-l-amber-500' : 'hover:bg-zinc-800/30 border-l-2 border-l-transparent'
                    }`}>
                    <GripVertical className="w-3 h-3 text-zinc-700 shrink-0" />
                    <span className="text-[10px] text-zinc-600 w-4 shrink-0 tabular-nums">{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className={`text-[11px] font-medium truncate leading-snug ${isActive ? 'text-amber-300' : 'text-zinc-300'}`}>{item.title}</div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <span className="text-[9px] text-zinc-600">{item.slides.length} slides</span>
                        {isLiveRow && (
                          <span className="flex items-center gap-0.5 text-[9px] text-red-400">
                            <span className="w-1 h-1 rounded-full bg-red-500 animate-pulse" />vivo
                          </span>
                        )}
                      </div>
                    </div>
                    <button onClick={e => { e.stopPropagation(); removeFromSetlist(i); }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-zinc-700 rounded transition-all shrink-0">
                      <X className="w-3 h-3 text-zinc-400" />
                    </button>
                  </div>
                );
              })
            }
          </div>
        </div>

        {/* ── SLIDE GRID ──────────────────────────────────────────────────────── */}
        <div className="flex-1 flex flex-col overflow-hidden bg-zinc-950 min-w-0">
          {currentItem && (
            <div className="h-10 shrink-0 border-b border-zinc-800 flex items-center px-4 gap-3 bg-zinc-900/30">
              <span className="font-serif text-sm text-zinc-100 truncate">{currentItem.title}</span>
              {currentItem.author && <span className="text-[11px] text-zinc-600 truncate">{currentItem.author}</span>}
              <div className="flex-1" />
              {currentItem.category && (
                <span className="text-[9px] uppercase tracking-wide text-zinc-600 bg-zinc-800 px-1.5 py-0.5 rounded">{currentItem.category}</span>
              )}
            </div>
          )}
          <SlideGrid
            item={currentItem}
            activeSetlistIdx={activeSetlistIdx}
            liveSetlistIdx={liveSetlistIdx}
            liveSlideIdx={liveSlideIdx}
            activeSlideIdx={activeSlideIdx}
            isLive={isLive}
            theme={theme}
            onSlideClick={handleSlideClick}
            onEditSlide={(slideIdx, slide) => setEditingSlide({ setlistIdx: activeSetlistIdx, slideIdx, slide })}
            onDeleteSlide={deleteSlide}
            onMoveSlide={moveSlide}
            onAddSlide={addSlide}
          />
        </div>

        {/* ── LIVE OUTPUT PANEL ───────────────────────────────────────────────── */}
        <aside className="w-72 shrink-0 bg-zinc-900 border-l border-zinc-800 flex flex-col overflow-hidden">
          <LiveOutput
            isLive={isLive}
            outputMode={outputMode}
            theme={theme}
            liveSlide={liveSlide}
            nextSlide={nextSlide}
            liveTitle={liveItem?.title}
            liveInfo={liveSlide?.label}
            currentSlideNum={(liveSlideIdx ?? 0) + 1}
            totalSlides={liveItem?.slides.length ?? 0}
            liveMedia={liveMedia}
            onPrev={goPrevSlide}
            onNext={goNextSlide}
            onToggleBlack={() => setOutputMode(m => m === 'black' ? 'slide' : 'black')}
            onStopLive={stopLive}
            onStartLive={() => startLive(activeSetlistIdx, activeSlideIdx)}
            onSetOutputMode={setOutputMode}
            isFrozen={isFrozen}
            onToggleFreeze={() => setIsFrozen(f => !f)}
            autoplay={autoplay}
            autoplayInterval={autoplayInterval}
            onToggleAutoplay={() => setAutoplay(a => !a)}
            onSetAutoplayInterval={setAutoplayInterval}
            bgMedia={bgMedia}
            onClearBgMedia={() => setBgMedia(null)}
          />

          {/* Theme picker */}
          <div className="px-3 pb-3 border-t border-zinc-800 shrink-0">
            <div className="text-[10px] uppercase tracking-wider text-zinc-500 mt-3 mb-2 flex items-center gap-1.5">
              <Palette className="w-3 h-3" /> Tema visual
            </div>
            <div className="grid grid-cols-8 gap-1">
              {defaultThemes.map(t => (
                <button key={t.id} onClick={() => setActiveThemeId(t.id)} title={t.name}
                  className={`aspect-square rounded border-2 transition-all ${
                    activeThemeId === t.id ? 'border-amber-400 scale-110 shadow-[0_0_6px_rgba(245,158,11,0.4)]' : 'border-zinc-700 hover:border-zinc-500'
                  }`}
                  style={{ background: t.preview }} />
              ))}
            </div>
            <div className="text-[10px] text-zinc-500 mt-1">{theme.name}</div>
          </div>
        </aside>
      </div>

      {/* ══ STATUS BAR ══════════════════════════════════════════════════════════ */}
      <footer className="h-6 shrink-0 bg-zinc-900 border-t border-zinc-800 flex items-center px-4 gap-3 text-[10px] text-zinc-600">
        <span>Lumen Live v2.0</span>
        <span className="text-zinc-800">·</span>
        <span>← → slide · B negro · L logo · C limpiar · F congelar · ESC detener</span>
        <div className="flex-1" />
        {isLive && liveItem && (
          <span className="text-red-400 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            {liveItem.title} · {(liveSlideIdx ?? 0) + 1}/{liveItem.slides.length}
          </span>
        )}
        <span className="text-zinc-700">{setlist.length} servicio · {songs.length} cantos</span>
      </footer>

      {/* ══ MODALS ══════════════════════════════════════════════════════════════ */}
      {songModal && (
        <SongModal song={songModal.song} onSave={saveSong} onClose={() => setSongModal(null)} />
      )}
      {editingSlide && (
        <SlideEditModal
          slide={editingSlide.slide}
          onSave={s => updateSetlistSlide(editingSlide.setlistIdx, editingSlide.slideIdx, s)}
          onClose={() => setEditingSlide(null)}
        />
      )}
      {confirmDelete && (
        <ConfirmDialog
          message={confirmDelete.message}
          onConfirm={() => { if (confirmDelete.type === 'song') deleteSong(confirmDelete.id); }}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
    </div>
  );
}
