import { uid } from '../store';

/**
 * AI service — frontend side.
 *
 * All functions POST to /api/ai (the Express server in server/index.js).
 * The OPENAI_API_KEY lives exclusively in the server; this file never
 * touches it. In development, Vite proxies /api → http://localhost:3001.
 */

// ─── Core fetch helper ────────────────────────────────────────────────────────

async function callApi(action, payload) {
  const res = await fetch('/api/ai', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, payload }),
  });

  const data = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));

  if (!res.ok || data.error) {
    throw new Error(data.error || `Server error ${res.status}`);
  }

  return data;
}

// ─── 1. Split lyrics into slides ──────────────────────────────────────────────

export async function splitLyricsIntoSlides(lyrics) {
  if (!lyrics?.trim()) throw new Error('Ingresa la letra del canto.');

  const { slides } = await callApi('splitLyrics', { lyrics });

  return slides.map(s => ({
    id:     uid(),
    label:  s.label  ?? 'Slide',
    title:  '',
    lyrics: s.lyrics ?? '',
  }));
}

// ─── 2. Translate lyrics ───────────────────────────────────────────────────────

export async function translateLyrics(lyrics, targetLang) {
  if (!lyrics?.trim())    throw new Error('Ingresa la letra a traducir.');
  if (!targetLang?.trim()) throw new Error('Selecciona un idioma destino.');

  const { translation } = await callApi('translateLyrics', { lyrics, targetLang });
  return translation;
}

// ─── 3. Sermon outline ────────────────────────────────────────────────────────

export async function generateSermonOutline(topic) {
  if (!topic?.trim()) throw new Error('Ingresa el tema del sermón.');

  const { outline } = await callApi('sermonOutline', { topic });
  return outline;
}

// ─── 4. Background image suggestions ─────────────────────────────────────────

export async function suggestBackgrounds(input) {
  if (!input?.trim()) throw new Error('Ingresa el nombre del canto o tema.');

  const { queries } = await callApi('suggestBackgrounds', { input });
  return queries;
}

// ─── 5. Lower-thirds ──────────────────────────────────────────────────────────

export async function generateLowerThirds(context) {
  if (!context?.trim()) throw new Error('Ingresa el contexto para los rótulos.');

  const { items } = await callApi('lowerThirds', { context });
  return items;
}

// ─── 6. Church announcement ───────────────────────────────────────────────────

export async function generateAnnouncement(brief) {
  if (!brief?.trim()) throw new Error('Describe el anuncio brevemente.');

  const { announcement } = await callApi('announcement', { brief });
  return announcement;
}

// ─── 7. Verse to sermon points ────────────────────────────────────────────────

export async function verseToSermonPoints(verse) {
  if (!verse?.trim()) throw new Error('Ingresa el versículo bíblico.');

  const { points } = await callApi('verseToPoints', { verse });
  return points;
}
