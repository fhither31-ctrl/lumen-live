import React, { useState, useEffect } from 'react';
import { Sparkles, Loader, Copy, Plus, ChevronDown, ChevronUp, Languages, BookOpen, ChevronLeft as AlignLeft, Mic, Image as ImageIcon, Megaphone, Check, X, ExternalLink, CircleAlert as AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { uid } from '../store';
import {
  splitLyricsIntoSlides, translateLyrics, generateSermonOutline,
  suggestBackgrounds, generateLowerThirds, generateAnnouncement,
  verseToSermonPoints,
} from '../api/aiService';

const PEXELS_BASE = 'https://www.pexels.com/search/';

// ─── Server status banner ─────────────────────────────────────────────────────
function ServerStatusBanner() {
  const [status, setStatus] = useState('checking'); // checking | ok | error

  useEffect(() => {
    let cancelled = false;
    let attempts = 0;

    function check() {
      fetch('/api/health')
        .then(r => r.json())
        .then(d => {
          if (cancelled) return;
          setStatus(d.ok && d.openai ? 'ok' : d.ok ? 'no-key' : 'error');
        })
        .catch(() => {
          if (cancelled) return;
          attempts += 1;
          if (attempts < 5) {
            setTimeout(check, 2000);
          } else {
            setStatus('error');
          }
        });
    }

    check();
    return () => { cancelled = true; };
  }, []);

  if (status === 'checking') {
    return (
      <div className="mx-2 mb-2 flex items-center gap-2 px-2.5 py-2 rounded-xl border bg-zinc-900 border-zinc-800 text-[10px] text-zinc-500">
        <Loader className="w-3 h-3 animate-spin shrink-0" />
        Verificando conexión con servidor de IA…
      </div>
    );
  }

  if (status === 'ok') {
    return (
      <div className="mx-2 mb-2 flex items-center gap-2 px-2.5 py-2 rounded-xl border bg-emerald-950/30 border-emerald-800/40 text-[10px] text-emerald-400">
        <Wifi className="w-3 h-3 shrink-0" />
        Servidor de IA conectado — OpenAI activo
      </div>
    );
  }

  if (status === 'no-key') {
    return (
      <div className="mx-2 mb-2 p-2.5 rounded-xl border bg-amber-950/30 border-amber-800/40 text-[10px]">
        <div className="flex items-center gap-1.5 text-amber-400 font-medium mb-1">
          <AlertCircle className="w-3 h-3" /> OPENAI_API_KEY no configurada
        </div>
        <p className="text-amber-600 leading-relaxed">
          El servidor está corriendo pero falta la clave. Agrega{' '}
          <code className="bg-amber-950 px-1 rounded font-mono">OPENAI_API_KEY=sk-…</code>{' '}
          al archivo <code className="bg-amber-950 px-1 rounded font-mono">server/.env</code>{' '}
          y reinicia el servidor.
        </p>
      </div>
    );
  }

  // error — server not reachable
  return (
    <div className="mx-2 mb-2 p-2.5 rounded-xl border bg-red-950/20 border-red-900/40 text-[10px]">
      <div className="flex items-center gap-1.5 text-red-400 font-medium mb-1">
        <WifiOff className="w-3 h-3" /> Servidor de IA no disponible
      </div>
      <p className="text-red-600 leading-relaxed">
        Inicia el servidor con:{' '}
        <code className="bg-red-950 px-1 rounded font-mono">cd server && npm install && npm run dev</code>
      </p>
    </div>
  );
}

// ─── UI primitives ────────────────────────────────────────────────────────────
function ToolCard({ icon: Icon, title, description, children, defaultOpen = false, accent = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={`border rounded-xl overflow-hidden ${accent ? 'border-amber-800/50' : 'border-zinc-800'}`}>
      <button
        onClick={() => setOpen(o => !o)}
        className={`w-full flex items-center gap-2.5 px-3 py-2.5 transition-colors text-left ${
          accent ? 'bg-amber-950/30 hover:bg-amber-950/50' : 'bg-zinc-900 hover:bg-zinc-800/70'
        }`}>
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
          accent
            ? 'bg-gradient-to-br from-amber-600/60 to-orange-700/60 border border-amber-700/40'
            : 'bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/40'
        }`}>
          <Icon className={`w-3.5 h-3.5 ${accent ? 'text-amber-300' : 'text-amber-400'}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-medium text-zinc-200">{title}</div>
          <div className="text-[10px] text-zinc-500 truncate">{description}</div>
        </div>
        {open
          ? <ChevronUp className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
          : <ChevronDown className="w-3.5 h-3.5 text-zinc-600 shrink-0" />}
      </button>
      {open && (
        <div className="p-3 bg-zinc-950 border-t border-zinc-800/60">
          {children}
        </div>
      )}
    </div>
  );
}

function RunButton({ loading, loadingLabel, idleLabel, icon: Icon, onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={loading || disabled}
      className="w-full flex items-center justify-center gap-2 text-xs py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white disabled:opacity-40 transition-colors font-medium mt-2">
      {loading
        ? <><Loader className="w-3.5 h-3.5 animate-spin" />{loadingLabel}</>
        : <><Icon className="w-3.5 h-3.5" />{idleLabel}</>}
    </button>
  );
}

function TextArea({ value, onChange, rows = 3, placeholder }) {
  return (
    <textarea value={value} onChange={e => onChange(e.target.value)} rows={rows}
      placeholder={placeholder}
      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg text-xs px-2.5 py-2 text-zinc-200 focus:outline-none focus:border-amber-500 resize-none font-mono leading-relaxed" />
  );
}

function TextInput({ value, onChange, placeholder }) {
  return (
    <input value={value} onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full bg-zinc-800 border border-zinc-700 rounded-lg text-xs px-2.5 py-2 text-zinc-200 focus:outline-none focus:border-amber-500" />
  );
}

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  function doCopy() {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }
  return (
    <button onClick={doCopy}
      className="flex items-center gap-1 text-[10px] px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors">
      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
      {copied ? 'Copiado' : 'Copiar'}
    </button>
  );
}

function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div className="mt-2 flex items-start gap-1.5 text-[11px] text-red-400 bg-red-950/30 border border-red-900/40 rounded-lg px-2.5 py-2">
      <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
      <span>{message}</span>
    </div>
  );
}

function OutputText({ value, onAddSlides }) {
  if (!value) return null;
  return (
    <div className="mt-2 p-2.5 bg-zinc-900 rounded-lg border border-zinc-800">
      <pre className="text-[11px] text-zinc-300 whitespace-pre-wrap leading-relaxed">{value}</pre>
      <div className="flex gap-1.5 mt-2 flex-wrap">
        <CopyButton text={value} />
        {onAddSlides && (
          <button onClick={onAddSlides}
            className="flex items-center gap-1 text-[10px] px-2 py-1 rounded bg-amber-700 hover:bg-amber-600 text-white transition-colors">
            <Plus className="w-3 h-3" /> Agregar al servicio
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Slide preview list ───────────────────────────────────────────────────────
function SlidePreviewList({ slides }) {
  const LABEL_COLORS = {
    Verso:   'bg-blue-900/60 text-blue-300',
    Coro:    'bg-amber-900/60 text-amber-300',
    Puente:  'bg-emerald-900/60 text-emerald-300',
    Bridge:  'bg-emerald-900/60 text-emerald-300',
    Intro:   'bg-zinc-700/80 text-zinc-300',
    Outro:   'bg-zinc-700/80 text-zinc-300',
  };
  function labelColor(label) {
    const key = Object.keys(LABEL_COLORS).find(k => label?.toLowerCase().startsWith(k.toLowerCase()));
    return key ? LABEL_COLORS[key] : 'bg-zinc-800 text-zinc-400';
  }
  return (
    <div className="mt-2 space-y-1 max-h-52 overflow-y-auto pr-1">
      {slides.map((s, i) => (
        <div key={s.id || i} className="flex gap-2 p-2 bg-zinc-800/70 rounded-lg border border-zinc-700/50">
          <span className={`text-[9px] uppercase tracking-wide px-1.5 py-0.5 rounded font-medium shrink-0 self-start mt-0.5 ${labelColor(s.label)}`}>
            {s.label}
          </span>
          <p className="text-[11px] text-zinc-300 leading-snug whitespace-pre-line min-w-0">{s.lyrics}</p>
        </div>
      ))}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function AiStudio({ onAddToSetlist }) {

  // Split lyrics
  const [splitInput,   setSplitInput]   = useState('');
  const [splitResult,  setSplitResult]  = useState(null);
  const [splitLoading, setSplitLoading] = useState(false);
  const [splitError,   setSplitError]   = useState('');

  // Translate
  const [transInput,   setTransInput]   = useState('');
  const [transLang,    setTransLang]    = useState('English');
  const [transResult,  setTransResult]  = useState(null);
  const [transLoading, setTransLoading] = useState(false);
  const [transError,   setTransError]   = useState('');

  // Sermon outline
  const [outlineInput,   setOutlineInput]   = useState('');
  const [outlineResult,  setOutlineResult]  = useState(null);
  const [outlineLoading, setOutlineLoading] = useState(false);
  const [outlineError,   setOutlineError]   = useState('');

  // Background suggestions
  const [bgInput,   setBgInput]   = useState('');
  const [bgResult,  setBgResult]  = useState(null);
  const [bgLoading, setBgLoading] = useState(false);
  const [bgError,   setBgError]   = useState('');

  // Lower thirds
  const [lowerInput,   setLowerInput]   = useState('');
  const [lowerResult,  setLowerResult]  = useState(null);
  const [lowerLoading, setLowerLoading] = useState(false);
  const [lowerError,   setLowerError]   = useState('');

  // Announcements
  const [announceInput,   setAnnounceInput]   = useState('');
  const [announceResult,  setAnnounceResult]  = useState(null);
  const [announceLoading, setAnnounceLoading] = useState(false);
  const [announceError,   setAnnounceError]   = useState('');

  // ── Handlers ─────────────────────────────────────────────────────────────────
  async function doSplit() {
    if (!splitInput.trim()) return;
    setSplitLoading(true); setSplitError(''); setSplitResult(null);
    try {
      setSplitResult(await splitLyricsIntoSlides(splitInput));
    } catch (e) {
      setSplitError(e.message || 'Error al procesar');
    } finally {
      setSplitLoading(false);
    }
  }

  function addSplitSlides() {
    if (!splitResult?.length) return;
    onAddToSetlist({ id: uid(), title: 'Canto — AI Studio', author: 'AI', category: 'Adoración', slides: splitResult });
  }

  async function doTranslate() {
    if (!transInput.trim()) return;
    setTransLoading(true); setTransError(''); setTransResult(null);
    try {
      setTransResult(await translateLyrics(transInput, transLang));
    } catch (e) {
      setTransError(e.message || 'Error al traducir');
    } finally {
      setTransLoading(false);
    }
  }

  async function doOutline() {
    if (!outlineInput.trim()) return;
    setOutlineLoading(true); setOutlineError(''); setOutlineResult(null);
    try {
      setOutlineResult(await generateSermonOutline(outlineInput));
    } catch (e) {
      setOutlineError(e.message || 'Error al generar');
    } finally {
      setOutlineLoading(false);
    }
  }

  async function doBg() {
    if (!bgInput.trim()) return;
    setBgLoading(true); setBgError(''); setBgResult(null);
    try {
      setBgResult(await suggestBackgrounds(bgInput));
    } catch (e) {
      setBgError(e.message || 'Error al sugerir');
    } finally {
      setBgLoading(false);
    }
  }

  async function doLower() {
    if (!lowerInput.trim()) return;
    setLowerLoading(true); setLowerError(''); setLowerResult(null);
    try {
      setLowerResult(await generateLowerThirds(lowerInput));
    } catch (e) {
      setLowerError(e.message || 'Error al generar');
    } finally {
      setLowerLoading(false);
    }
  }

  async function doAnnounce() {
    if (!announceInput.trim()) return;
    setAnnounceLoading(true); setAnnounceError(''); setAnnounceResult(null);
    try {
      setAnnounceResult(await generateAnnouncement(announceInput));
    } catch (e) {
      setAnnounceError(e.message || 'Error al generar');
    } finally {
      setAnnounceLoading(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-zinc-800 shrink-0 flex items-center gap-2">
        <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center">
          <Sparkles className="w-3.5 h-3.5 text-zinc-950" />
        </div>
        <div>
          <div className="text-xs font-semibold text-zinc-200">AI Studio</div>
          <div className="text-[10px] text-zinc-500">Herramientas de IA — OpenAI gpt-4o-mini</div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 pt-2 pb-3 space-y-2">

        <ServerStatusBanner />

        {/* ── 1. Split lyrics into slides ── */}
        <div className="px-2">
          <ToolCard icon={AlignLeft} title="Generar slides desde letra" description="Pega la letra completa y divide en slides automáticamente" defaultOpen accent>
            <TextArea
              value={splitInput}
              onChange={setSplitInput}
              rows={5}
              placeholder={`Pega aquí la letra completa del canto.\n\nSepara secciones con líneas en blanco para mejor detección de Verso/Coro/Puente.`} />
            <RunButton
              loading={splitLoading}
              loadingLabel="Analizando letra…"
              idleLabel="Dividir en slides"
              icon={Sparkles}
              onClick={doSplit}
              disabled={!splitInput.trim()} />
            <ErrorBanner message={splitError} />
            {splitResult && (
              <>
                <div className="flex items-center justify-between mt-2 mb-0.5">
                  <span className="text-[10px] text-zinc-500">{splitResult.length} slides detectados</span>
                </div>
                <SlidePreviewList slides={splitResult} />
                <div className="flex gap-1.5 mt-2">
                  <CopyButton text={splitResult.map(s => `[${s.label}]\n${s.lyrics}`).join('\n\n')} />
                  <button onClick={addSplitSlides}
                    className="flex items-center gap-1 text-[10px] px-2 py-1 rounded bg-amber-700 hover:bg-amber-600 text-white transition-colors">
                    <Plus className="w-3 h-3" /> Agregar al servicio
                  </button>
                </div>
              </>
            )}
          </ToolCard>
        </div>

        {/* ── 2. Translate lyrics ── */}
        <div className="px-2">
          <ToolCard icon={Languages} title="Traducir letra" description="Español · English · Português · Italiano">
            <TextArea
              value={transInput}
              onChange={setTransInput}
              rows={4}
              placeholder="Pega la letra a traducir…" />
            <div className="flex flex-wrap gap-1 mt-2">
              {['English', 'Português', 'Italiano', 'Español'].map(l => (
                <button key={l} onClick={() => setTransLang(l)}
                  className={`text-[10px] px-2.5 py-1 rounded-full transition-colors border ${
                    transLang === l
                      ? 'bg-amber-600 border-amber-500 text-white font-medium'
                      : 'bg-zinc-800 border-zinc-700 hover:border-zinc-600 text-zinc-400'
                  }`}>
                  {l}
                </button>
              ))}
            </div>
            <RunButton
              loading={transLoading}
              loadingLabel="Traduciendo…"
              idleLabel={`Traducir a ${transLang}`}
              icon={Languages}
              onClick={doTranslate}
              disabled={!transInput.trim()} />
            <ErrorBanner message={transError} />
            {transResult && (
              <OutputText
                value={transResult}
                onAddSlides={() => onAddToSetlist({
                  id: uid(), title: `Traducción ${transLang}`, author: 'AI', category: 'Adoración',
                  slides: transResult.split('\n\n').filter(Boolean).map((block, i) => ({
                    id: uid(), label: `Slide ${i + 1}`, title: '', lyrics: block,
                  })),
                })}
              />
            )}
          </ToolCard>
        </div>

        {/* ── 3. Sermon outline ── */}
        <div className="px-2">
          <ToolCard icon={Mic} title="Bosquejo de sermón" description="Genera un bosquejo completo desde un tema">
            <TextInput
              value={outlineInput}
              onChange={setOutlineInput}
              placeholder="Tema del sermón (ej: La gracia de Dios, La fe que mueve montañas)" />
            <RunButton
              loading={outlineLoading}
              loadingLabel="Generando bosquejo…"
              idleLabel="Generar bosquejo"
              icon={Mic}
              onClick={doOutline}
              disabled={!outlineInput.trim()} />
            <ErrorBanner message={outlineError} />
            <OutputText value={outlineResult} />
          </ToolCard>
        </div>

        {/* ── 4. Background image suggestions ── */}
        <div className="px-2">
          <ToolCard icon={ImageIcon} title="Sugerir fondos para Pexels" description="Frases de búsqueda según el tema o canto">
            <TextInput
              value={bgInput}
              onChange={setBgInput}
              placeholder="Nombre del canto o tema (ej: Sublime Gracia, paz, amor de Dios)" />
            <RunButton
              loading={bgLoading}
              loadingLabel="Analizando…"
              idleLabel="Sugerir fondos"
              icon={ImageIcon}
              onClick={doBg}
              disabled={!bgInput.trim()} />
            <ErrorBanner message={bgError} />
            {bgResult && (
              <div className="mt-2 space-y-1.5">
                <div className="text-[10px] text-zinc-500 mb-1">Buscar en Pexels:</div>
                {bgResult.map((tag, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 bg-zinc-800/70 rounded-lg border border-zinc-700/50">
                    <span className="flex-1 text-xs text-amber-300">{tag}</span>
                    <a
                      href={`${PEXELS_BASE}${encodeURIComponent(tag)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-[10px] px-2 py-1 rounded bg-zinc-700 hover:bg-zinc-600 text-zinc-300 transition-colors shrink-0">
                      <ExternalLink className="w-3 h-3" /> Pexels
                    </a>
                  </div>
                ))}
              </div>
            )}
          </ToolCard>
        </div>

        {/* ── 5. Lower thirds ── */}
        <div className="px-2">
          <ToolCard icon={AlignLeft} title="Rótulos para transmisión" description="Lower-thirds listos para livestream">
            <TextInput
              value={lowerInput}
              onChange={setLowerInput}
              placeholder="Contexto (ej: nombre del predicador, tema del sermón)" />
            <RunButton
              loading={lowerLoading}
              loadingLabel="Generando…"
              idleLabel="Generar rótulos"
              icon={Sparkles}
              onClick={doLower}
              disabled={!lowerInput.trim()} />
            <ErrorBanner message={lowerError} />
            {lowerResult && (
              <div className="mt-2 space-y-1">
                {lowerResult.map((line, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 bg-zinc-800/70 rounded border border-zinc-700/50">
                    <span className="flex-1 text-xs text-zinc-300">{line}</span>
                    <CopyButton text={line} />
                  </div>
                ))}
              </div>
            )}
          </ToolCard>
        </div>

        {/* ── 6. Announcements ── */}
        <div className="px-2">
          <ToolCard icon={Megaphone} title="Generar anuncio" description="Crea un anuncio desde texto simple">
            <TextArea
              value={announceInput}
              onChange={setAnnounceInput}
              rows={2}
              placeholder="Describe el anuncio brevemente… (ej: Retiro de jóvenes el sábado 5, hora 9am, costo $15)" />
            <RunButton
              loading={announceLoading}
              loadingLabel="Generando…"
              idleLabel="Generar anuncio"
              icon={Megaphone}
              onClick={doAnnounce}
              disabled={!announceInput.trim()} />
            <ErrorBanner message={announceError} />
            <OutputText
              value={announceResult}
              onAddSlides={() => onAddToSetlist({
                id: uid(), title: 'Anuncio', author: 'AI', category: 'Anuncios',
                slides: [{ id: uid(), label: 'Anuncio', title: '', lyrics: announceResult }],
              })} />
          </ToolCard>
        </div>

        {/* ── 7. Verse to sermon points ── */}
        <div className="px-2">
          <ToolCard icon={BookOpen} title="Versículo → Puntos de sermón" description="Convierte un texto bíblico en puntos predicables">
            <VerseToPoints onAddToSetlist={onAddToSetlist} />
          </ToolCard>
        </div>

      </div>
    </div>
  );
}

// ─── Verse-to-points sub-component ───────────────────────────────────────────
function VerseToPoints({ onAddToSetlist }) {
  const [input,   setInput]   = useState('');
  const [result,  setResult]  = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  async function run() {
    if (!input.trim()) return;
    setLoading(true); setError(''); setResult(null);
    try {
      setResult(await verseToSermonPoints(input));
    } catch (e) {
      setError(e.message || 'Error al generar');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <textarea value={input} onChange={e => setInput(e.target.value)} rows={3}
        placeholder="Pega el versículo bíblico…"
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg text-xs px-2.5 py-2 text-zinc-200 focus:outline-none focus:border-amber-500 resize-none font-mono leading-relaxed" />
      <RunButton
        loading={loading}
        loadingLabel="Generando puntos…"
        idleLabel="Generar puntos de sermón"
        icon={BookOpen}
        onClick={run}
        disabled={!input.trim()} />
      <ErrorBanner message={error} />
      <OutputText value={result} />
    </>
  );
}
