import React, { useState, useMemo } from 'react';
import { Search, BookOpen, Plus, Check } from 'lucide-react';
import { uid } from '../store';

const BIBLE = {
  Génesis: {
    1: ['En el principio creó Dios los cielos y la tierra.', 'Y la tierra estaba desordenada y vacía.', 'Y dijo Dios: Sea la luz; y fue la luz.'],
  },
  Salmos: {
    23: [
      'El Señor es mi pastor; nada me faltará.',
      'En lugares de delicados pastos me hará descansar.',
      'Confortará mi alma; me guiará por sendas de justicia.',
      'Aunque ande en valle de sombra de muerte, no temeré mal alguno.',
      'Aderezas mesa delante de mí en presencia de mis angustiadores.',
      'Ciertamente el bien y la misericordia me seguirán todos los días de mi vida.',
    ],
    91: [
      'El que habita al abrigo del Altísimo morará bajo la sombra del Omnipotente.',
      'Diré yo a Jehová: Esperanza mía, y castillo mío; mi Dios, en quien confiaré.',
      'Él te librará del lazo del cazador, de la peste destructora.',
    ],
    100: [
      'Cantad alegres a Dios, habitantes de toda la tierra.',
      'Servid a Jehová con alegría; venid ante su presencia con regocijo.',
      'Reconoced que Jehová es Dios; él nos hizo, y no nosotros a nosotros mismos.',
    ],
  },
  Proverbios: {
    3: [
      'Fíate de Jehová de todo tu corazón, y no te apoyes en tu propia prudencia.',
      'Reconócelo en todos tus caminos, y él enderezará tus veredas.',
    ],
  },
  Juan: {
    1: ['En el principio era el Verbo, y el Verbo era con Dios, y el Verbo era Dios.', 'Y el Verbo se hizo carne, y habitó entre nosotros.'],
    3: ['Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito.', 'Para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.'],
    14: ['No se turbe vuestro corazón; creéis en Dios, creed también en mí.', 'En la casa de mi Padre muchas moradas hay.', 'Yo soy el camino, y la verdad, y la vida.'],
  },
  Romanos: {
    8: ['Ahora, pues, ninguna condenación hay para los que están en Cristo Jesús.', 'Porque el Señor es el Espíritu; y donde está el Espíritu del Señor, allí hay libertad.'],
  },
  Filipenses: {
    4: [
      'No os afanéis por nada; sino sean conocidas vuestras peticiones delante de Dios.',
      'Y la paz de Dios, que sobrepasa todo entendimiento, guardará vuestros corazones.',
      'Todo lo puedo en Cristo que me fortalece.',
    ],
  },
  Hebreos: {
    11: ['Es, pues, la fe la certeza de lo que se espera, la convicción de lo que no se ve.'],
  },
  Apocalipsis: {
    1:  ['Yo soy el Alfa y la Omega, principio y fin, dice el Señor.'],
    22: ['Yo Jesús he enviado mi ángel para daros testimonio de estas cosas en las iglesias.'],
  },
};

const BOOKS = Object.keys(BIBLE);

export default function BiblePanel({ onAddToSetlist }) {
  const [book, setBook]         = useState('Salmos');
  const [chapter, setChapter]   = useState('23');
  const [query, setQuery]       = useState('');
  const [selected, setSelected] = useState(new Set());

  const chapters = Object.keys(BIBLE[book] || {});
  const verses   = BIBLE[book]?.[chapter] || [];

  const searchResults = useMemo(() => {
    if (!query.trim()) return null;
    const q = query.toLowerCase();
    const out = [];
    for (const b of BOOKS) {
      for (const ch of Object.keys(BIBLE[b])) {
        BIBLE[b][ch].forEach((v, i) => {
          if (v.toLowerCase().includes(q)) out.push({ book: b, chapter: ch, verse: i + 1, text: v });
        });
      }
    }
    return out;
  }, [query]);

  function toggle(i) {
    const next = new Set(selected);
    next.has(i) ? next.delete(i) : next.add(i);
    setSelected(next);
  }

  function addSingle(b, ch, verseIdx, text) {
    onAddToSetlist({
      id: `b-${b}-${ch}-${verseIdx}-${uid()}`,
      title: `${b} ${ch}:${verseIdx + 1}`,
      author: 'Reina-Valera 1960',
      category: 'Biblia',
      slides: [{ id: uid(), label: `${b} ${ch}:${verseIdx + 1}`, title: '', lyrics: text }],
    });
  }

  function addSelected() {
    if (!selected.size) return;
    const idxs = [...selected].sort((a, b) => a - b);
    onAddToSetlist({
      id: `b-${book}-${chapter}-${uid()}`,
      title: `${book} ${chapter}:${idxs.map(i => i + 1).join(',')}`,
      author: 'Reina-Valera 1960',
      category: 'Biblia',
      slides: idxs.map(i => ({ id: uid(), label: `${book} ${chapter}:${i + 1}`, title: '', lyrics: verses[i] })),
    });
    setSelected(new Set());
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      {/* Controls */}
      <div className="p-2 border-b border-zinc-800 space-y-1.5 shrink-0">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Buscar en la Biblia…"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-lg text-xs pl-7 pr-2 py-1.5 text-zinc-200 focus:outline-none focus:border-amber-600 transition-colors" />
        </div>
        {!query && (
          <div className="flex gap-1">
            <select value={book}
              onChange={e => { setBook(e.target.value); setChapter(Object.keys(BIBLE[e.target.value])[0]); setSelected(new Set()); }}
              className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg text-xs px-2 py-1.5 text-zinc-200 focus:outline-none focus:border-amber-600">
              {BOOKS.map(b => <option key={b}>{b}</option>)}
            </select>
            <select value={chapter} onChange={e => { setChapter(e.target.value); setSelected(new Set()); }}
              className="w-14 bg-zinc-950 border border-zinc-800 rounded-lg text-xs px-2 py-1.5 text-zinc-200 focus:outline-none focus:border-amber-600">
              {chapters.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        )}
      </div>

      {/* Verses */}
      <div className="overflow-y-auto flex-1 min-h-0">
        {query && searchResults ? (
          <>
            <div className="px-3 py-1.5 text-[10px] text-zinc-500 bg-zinc-900/80 sticky top-0 border-b border-zinc-800/50">
              {searchResults.length} resultado{searchResults.length !== 1 ? 's' : ''}
            </div>
            {searchResults.length === 0
              ? <div className="flex flex-col items-center justify-center py-12 text-zinc-700"><BookOpen className="w-8 h-8 mb-2" /><div className="text-xs">Sin resultados</div></div>
              : searchResults.map((r, i) => (
                  <button key={i} onClick={() => addSingle(r.book, r.chapter, r.verse - 1, r.text)}
                    className="w-full text-left px-3 py-2.5 hover:bg-zinc-800/60 border-b border-zinc-800/40 group transition-colors">
                    <div className="text-[10px] text-amber-500/80 mb-0.5 font-medium">{r.book} {r.chapter}:{r.verse}</div>
                    <div className="text-xs text-zinc-300 leading-snug">{r.text}</div>
                    <div className="text-[9px] text-zinc-600 mt-1 group-hover:text-amber-500 transition-colors flex items-center gap-1">
                      <Plus className="w-2.5 h-2.5" /> Agregar al servicio
                    </div>
                  </button>
                ))
            }
          </>
        ) : (
          <>
            <div className="px-3 py-1.5 flex items-center justify-between sticky top-0 bg-zinc-900/95 border-b border-zinc-800/50 backdrop-blur-sm">
              <span className="text-[10px] uppercase tracking-wider text-zinc-500">{book} {chapter}</span>
              {selected.size > 0 && (
                <button onClick={addSelected}
                  className="flex items-center gap-1 text-[10px] bg-amber-600 hover:bg-amber-500 text-white px-2 py-0.5 rounded transition-colors">
                  <Check className="w-2.5 h-2.5" /> {selected.size} vers.
                </button>
              )}
            </div>
            {verses.map((v, i) => (
              <div key={i} className="flex items-start gap-2 px-3 py-2.5 hover:bg-zinc-800/50 border-b border-zinc-800/40 group transition-colors">
                <input type="checkbox" checked={selected.has(i)} onChange={() => toggle(i)}
                  className="mt-0.5 accent-amber-500 shrink-0 cursor-pointer" />
                <span className="text-[10px] text-amber-500/70 font-semibold mt-0.5 shrink-0 w-4">{i + 1}</span>
                <span className="text-xs text-zinc-300 leading-snug flex-1">{v}</span>
                <button onClick={() => addSingle(book, chapter, i, v)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-zinc-700 rounded shrink-0 transition-all"
                  title="Agregar al servicio">
                  <Plus className="w-3 h-3 text-amber-400" />
                </button>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
