import React, { useEffect, useRef, useState } from 'react';
import {
  Monitor, ChevronLeft, ChevronRight, Circle,
  Square, Image as ImageIcon, EyeOff, Pause, Play,
  Timer, Snowflake, Layers, X,
} from 'lucide-react';

function SlideContent({ slide, theme, size = 'md', hasBg = false }) {
  const lines = slide?.lyrics ? slide.lyrics.split('\n').filter(Boolean) : [];
  const sizes = { sm: 'text-xs', md: 'text-sm lg:text-base', lg: 'text-xl lg:text-2xl' };
  const bgClass   = hasBg ? 'bg-transparent' : (theme?.bgClass ?? 'bg-zinc-950');
  const textClass = hasBg ? 'text-white'     : (theme?.textClass ?? 'text-white');
  const fontClass = theme?.fontClass ?? 'font-serif';
  const shadow    = hasBg ? '0 1px 6px rgba(0,0,0,0.9)' : undefined;

  return (
    <div className={`absolute inset-0 ${bgClass} flex items-center justify-center transition-colors duration-300`}>
      {slide ? (
        <div className={`text-center px-6 ${textClass} ${fontClass}`}>
          {slide.title && (
            <div
              className={`${size === 'lg' ? 'text-xs' : 'text-[9px]'} uppercase tracking-[0.2em] opacity-70 mb-2`}
              style={{ textShadow: shadow }}>
              {slide.title}
            </div>
          )}
          {lines.map((line, i) => (
            <div key={i} className={`${sizes[size]} leading-relaxed`} style={{ textShadow: shadow }}>{line}</div>
          ))}
        </div>
      ) : (
        <div className="flex items-center gap-3 opacity-40">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center">
            <Circle className="w-5 h-5 text-zinc-950 fill-zinc-950" />
          </div>
          <div>
            <div className="font-serif text-xl text-zinc-300">Lumen</div>
            <div className="text-[9px] uppercase tracking-widest text-amber-500/70">Live</div>
          </div>
        </div>
      )}
    </div>
  );
}

// Segmented progress bar
function ProgressBar({ current, total }) {
  if (!total || total <= 1) return null;
  return (
    <div className="flex gap-0.5 mt-2">
      {Array.from({ length: total }, (_, i) => (
        <div
          key={i}
          className={`h-1 flex-1 rounded-full transition-all duration-300 ${
            i < current
              ? 'bg-amber-500'
              : i === current - 1
              ? 'bg-amber-400 animate-progressPulse'
              : 'bg-zinc-700'
          }`}
        />
      ))}
    </div>
  );
}

// Autoplay countdown ring
function AutoplayRing({ seconds, total }) {
  const r = 10;
  const circ = 2 * Math.PI * r;
  const progress = total > 0 ? (seconds / total) : 1;
  const dash = circ * (1 - progress);

  return (
    <svg width="28" height="28" className="shrink-0">
      <circle cx="14" cy="14" r={r} fill="none" stroke="#3f3f46" strokeWidth="2.5" />
      <circle
        cx="14" cy="14" r={r}
        fill="none"
        stroke="#f59e0b"
        strokeWidth="2.5"
        strokeDasharray={circ}
        strokeDashoffset={dash}
        strokeLinecap="round"
        transform="rotate(-90 14 14)"
        style={{ transition: 'stroke-dashoffset 1s linear' }}
      />
      <text x="14" y="18" textAnchor="middle" fontSize="9" fill="#fbbf24" fontFamily="monospace">
        {seconds}
      </text>
    </svg>
  );
}

export default function LiveOutput({
  isLive, outputMode, theme,
  liveSlide, nextSlide, liveTitle, liveInfo,
  onPrev, onNext, onToggleBlack, onStopLive, onStartLive,
  currentSlideNum, totalSlides,
  isFrozen, onToggleFreeze,
  autoplay, autoplayInterval, onToggleAutoplay, onSetAutoplayInterval,
  onSetOutputMode,
  bgMedia, onClearBgMedia,
}) {
  const [animKey, setAnimKey] = useState(0);
  const prevSlideRef = useRef(liveSlide);
  const [autoplayCountdown, setAutoplayCountdown] = useState(autoplayInterval ?? 5);

  // Bump animKey on slide change for fade animation
  useEffect(() => {
    if (liveSlide !== prevSlideRef.current) {
      setAnimKey(k => k + 1);
      prevSlideRef.current = liveSlide;
    }
  }, [liveSlide]);

  // Reset countdown when autoplay fires or interval changes
  useEffect(() => {
    setAutoplayCountdown(autoplayInterval ?? 5);
  }, [currentSlideNum, autoplayInterval]);

  // Tick down countdown display
  useEffect(() => {
    if (!autoplay || !isLive) return;
    const t = setInterval(() => setAutoplayCountdown(n => Math.max(0, n - 1)), 1000);
    return () => clearInterval(t);
  }, [autoplay, isLive, currentSlideNum]);

  const showSlide = outputMode === 'slide' && liveSlide;
  const isBlack   = outputMode === 'black';
  const isClear   = outputMode === 'clear';
  const isLogo    = outputMode === 'logo';

  const OUTPUT_MODES = [
    { id: 'black', label: 'Negro', icon: Square,     activeClass: 'bg-zinc-200 text-zinc-900', key: 'B' },
    { id: 'logo',  label: 'Logo',  icon: Circle,     activeClass: 'bg-amber-600 text-white',   key: 'L' },
    { id: 'clear', label: 'Limpiar', icon: EyeOff,   activeClass: 'bg-zinc-600 text-white',    key: 'C' },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-zinc-800 shrink-0">
        <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-zinc-500">
          <Monitor className="w-3.5 h-3.5" />
          Salida
        </div>
        <div className="flex items-center gap-1.5">
          {isFrozen && (
            <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-blue-950/50 border border-blue-700/40 text-blue-400">
              <Snowflake className="w-3 h-3" /> Congelado
            </span>
          )}
          <div className={`flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded-full border transition-colors ${
            isLive
              ? 'bg-red-500/10 border-red-500/40 text-red-400'
              : 'bg-zinc-800 border-zinc-700 text-zinc-500'
          }`}>
            {isLive && <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />}
            {isLive ? 'EN VIVO' : 'DETENIDO'}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col overflow-y-auto p-3 gap-3 min-h-0">

        {/* ── Main live display ── */}
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1.5 flex items-center justify-between">
            <span>Principal</span>
            {liveTitle && <span className="text-zinc-600 truncate max-w-[120px]">{liveTitle}</span>}
          </div>

          {/* Preview window */}
          <div className={`relative aspect-video rounded-lg overflow-hidden border transition-all duration-200 ${
            isLive ? 'border-red-500/60 shadow-[0_0_0_1px_rgba(239,68,68,0.2),0_0_20px_rgba(239,68,68,0.1)]' : 'border-zinc-700'
          }`}>
            {/* Background media layer in preview */}
            {bgMedia && !isBlack && !isClear && (
              <div className="absolute inset-0 z-0">
                {bgMedia.type === 'video'
                  ? <video src={bgMedia.url} className="w-full h-full object-cover" autoPlay loop muted playsInline />
                  : <img   src={bgMedia.url} alt="" className="w-full h-full object-cover" />
                }
                <div className="absolute inset-0 bg-black/50" />
              </div>
            )}

            {isBlack && <div className="absolute inset-0 bg-black z-10" />}
            {isClear && (
              <div className="absolute inset-0 bg-zinc-900 z-10 flex items-center justify-center">
                <span className="text-[10px] text-zinc-600 uppercase tracking-widest">Transparente</span>
              </div>
            )}
            {!isBlack && !isClear && (
              <div key={animKey} className="absolute inset-0 z-10 animate-crossFade">
                <SlideContent slide={showSlide ? liveSlide : null} theme={bgMedia ? null : theme} size="md" hasBg={!!bgMedia} />
              </div>
            )}

            {/* Freeze overlay */}
            {isFrozen && (
              <div className="absolute inset-0 flex items-end justify-center pb-2 pointer-events-none">
                <div className="flex items-center gap-1 text-[9px] px-2 py-1 bg-blue-950/80 border border-blue-700/50 rounded-full text-blue-300">
                  <Snowflake className="w-3 h-3" /> CONGELADO
                </div>
              </div>
            )}

            {/* Slide counter + autoplay ring */}
            {isLive && totalSlides > 0 && (
              <div className="absolute bottom-2 right-2 flex items-center gap-1">
                {autoplay && isLive && (
                  <AutoplayRing seconds={autoplayCountdown} total={autoplayInterval ?? 5} />
                )}
                <div className="text-[9px] bg-black/60 text-white/70 px-1.5 py-0.5 rounded">
                  {currentSlideNum}/{totalSlides}
                </div>
              </div>
            )}

            {/* Label badge */}
            {showSlide && liveSlide?.label && (
              <div className="absolute top-2 left-2 text-[9px] uppercase tracking-wide bg-black/50 text-white/80 px-1.5 py-0.5 rounded">
                {liveSlide.label}
              </div>
            )}
          </div>

          {/* Segmented progress bar */}
          <ProgressBar current={currentSlideNum} total={totalSlides} />

          {/* Active background indicator */}
          {bgMedia && (
            <div className="flex items-center gap-1.5 mt-1.5 px-2 py-1.5 bg-amber-950/30 border border-amber-800/40 rounded-lg">
              <Layers className="w-3 h-3 text-amber-400 shrink-0" />
              <span className="text-[10px] text-amber-300 flex-1 truncate min-w-0">{bgMedia.name}</span>
              <button
                onClick={onClearBgMedia}
                className="p-0.5 hover:bg-amber-800/40 rounded text-amber-500 hover:text-amber-200 transition-colors shrink-0">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Nav controls */}
          <div className="flex items-center gap-1.5 mt-2">
            <button onClick={onPrev} disabled={!isLive}
              className="flex-1 flex items-center justify-center gap-1 text-xs py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:cursor-not-allowed text-zinc-300 transition-colors">
              <ChevronLeft className="w-3.5 h-3.5" /> Ant.
            </button>
            <button onClick={onNext} disabled={!isLive}
              className="flex-1 flex items-center justify-center gap-1 text-xs py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 disabled:cursor-not-allowed text-zinc-300 transition-colors">
              Sig. <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Live info */}
          {isLive && liveInfo && (
            <div className="text-[10px] text-center text-zinc-600 mt-1 truncate">{liveInfo}</div>
          )}
        </div>

        {/* ── Output mode buttons ── */}
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1.5">Modo de salida</div>
          <div className="grid grid-cols-3 gap-1">
            {OUTPUT_MODES.map(({ id, label, icon: Icon, activeClass, key }) => (
              <button
                key={id}
                onClick={() => onSetOutputMode(id)}
                title={`${label} (${key})`}
                className={`flex flex-col items-center gap-1 py-2 rounded-lg text-[10px] font-medium border transition-all ${
                  outputMode === id
                    ? `${activeClass} border-transparent shadow-sm`
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-400 border-zinc-700'
                }`}>
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* ── Freeze button ── */}
        <button
          onClick={onToggleFreeze}
          className={`flex items-center justify-center gap-1.5 text-xs py-2 rounded-lg border font-medium transition-all ${
            isFrozen
              ? 'bg-blue-900/50 border-blue-700/60 text-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.15)]'
              : 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-400'
          }`}>
          <Snowflake className="w-3.5 h-3.5" />
          {isFrozen ? 'Descongelar salida' : 'Congelar salida'}
        </button>

        {/* ── Autoplay ── */}
        <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-zinc-500">
              <Timer className="w-3 h-3" /> Avance automático
            </div>
            <button
              onClick={onToggleAutoplay}
              disabled={!isLive}
              className={`flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-lg font-medium border transition-all ${
                autoplay
                  ? 'bg-emerald-700 border-emerald-600 text-white'
                  : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-zinc-200 disabled:opacity-30'
              }`}>
              {autoplay
                ? <><Pause className="w-3 h-3" /> Activo</>
                : <><Play  className="w-3 h-3 fill-current" /> Iniciar</>}
            </button>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min={3} max={30} step={1}
              value={autoplayInterval ?? 5}
              onChange={e => onSetAutoplayInterval(Number(e.target.value))}
              className="flex-1 h-1.5 accent-amber-500 cursor-pointer" />
            <span className="text-[11px] font-mono text-zinc-300 w-8 text-right">
              {autoplayInterval ?? 5}s
            </span>
          </div>
          <div className="text-[9px] text-zinc-700 mt-1">Segundos por slide</div>
        </div>

        {/* ── Next slide preview ── */}
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1.5">Siguiente</div>
          <div className="relative aspect-video rounded-md overflow-hidden border border-zinc-800 opacity-50">
            <SlideContent slide={nextSlide} theme={theme} size="sm" />
            {!nextSlide && (
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-[10px] text-zinc-700">— fin —</span>
              </div>
            )}
          </div>
          {nextSlide?.label && (
            <div className="text-[9px] text-zinc-600 mt-1 truncate">{nextSlide.label}</div>
          )}
        </div>

      </div>
    </div>
  );
}
