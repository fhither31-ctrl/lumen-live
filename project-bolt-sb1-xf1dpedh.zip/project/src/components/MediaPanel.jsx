import React, { useRef, useState } from 'react';
import {
  Image as ImageIcon, Film, Upload, Trash2, Monitor,
  Layers, X, Check,
} from 'lucide-react';
import { uid } from '../store';

function fmtSize(b) {
  if (!b) return '';
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function MediaThumb({ item, isActiveBg, onSendToLive, onSetBg, onClearBg, onDelete }) {
  const [hover, setHover] = useState(false);

  return (
    <div
      className={`group relative rounded-xl overflow-hidden border bg-zinc-950 transition-all ${
        isActiveBg
          ? 'border-amber-500 shadow-[0_0_0_1px_rgba(245,158,11,0.3)]'
          : 'border-zinc-800 hover:border-zinc-600'
      }`}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {/* Thumbnail */}
      <div className="aspect-video w-full relative overflow-hidden">
        {item.type === 'image' ? (
          <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
        ) : (
          <video
            src={item.url}
            className="w-full h-full object-cover"
            muted
            playsInline
            loop
            autoPlay={hover}
          />
        )}

        {/* Active bg badge */}
        {isActiveBg && (
          <div className="absolute top-1.5 left-1.5 flex items-center gap-1 text-[9px] bg-amber-600 text-white px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide">
            <Layers className="w-2.5 h-2.5" /> Fondo
          </div>
        )}

        {/* Type badge */}
        <div className="absolute top-1.5 right-1.5 text-[9px] bg-black/60 text-white/70 px-1.5 py-0.5 rounded uppercase">
          {item.type === 'video' ? <Film className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
        </div>

        {/* Hover actions overlay */}
        <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-2">
          <button
            onClick={() => onSendToLive(item)}
            className="w-full flex items-center justify-center gap-1 text-[10px] bg-red-600 hover:bg-red-500 text-white px-2 py-1.5 rounded-lg font-medium transition-colors">
            <Monitor className="w-3 h-3" /> Enviar en vivo
          </button>
          {isActiveBg ? (
            <button
              onClick={onClearBg}
              className="w-full flex items-center justify-center gap-1 text-[10px] bg-zinc-700 hover:bg-zinc-600 text-zinc-200 px-2 py-1.5 rounded-lg transition-colors">
              <X className="w-3 h-3" /> Quitar fondo
            </button>
          ) : (
            <button
              onClick={() => onSetBg(item)}
              className="w-full flex items-center justify-center gap-1 text-[10px] bg-amber-700 hover:bg-amber-600 text-white px-2 py-1.5 rounded-lg transition-colors">
              <Layers className="w-3 h-3" /> Usar de fondo
            </button>
          )}
          <button
            onClick={() => onDelete(item.id)}
            className="w-full flex items-center justify-center gap-1 text-[10px] bg-zinc-800 hover:bg-red-800 text-zinc-400 hover:text-white px-2 py-1.5 rounded-lg transition-colors">
            <Trash2 className="w-3 h-3" /> Eliminar
          </button>
        </div>
      </div>

      {/* Info strip */}
      <div className="px-2 py-1.5 bg-zinc-900">
        <div className="text-[10px] text-zinc-300 truncate leading-tight">{item.name}</div>
        <div className="text-[9px] text-zinc-600 mt-0.5">{fmtSize(item.size)}</div>
      </div>
    </div>
  );
}

export default function MediaPanel({
  mediaLibrary, setMediaLibrary,
  onSendToLive,
  bgMedia, onSetBgMedia, onClearBgMedia,
}) {
  const fileRef   = useRef();
  const [loading, setLoading] = useState(false);

  async function handleFiles(files) {
    setLoading(true);
    try {
      const items = await Promise.all(
        [...files].map(async (f) => ({
          id:   uid(),
          name: f.name,
          type: f.type.startsWith('video') ? 'video' : 'image',
          url:  await fileToDataUrl(f),
          size: f.size,
        }))
      );
      setMediaLibrary(prev => [...prev, ...items]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">

      {/* Active background indicator */}
      {bgMedia && (
        <div className="mx-2 mt-2 flex items-center gap-2 px-2.5 py-2 bg-amber-950/30 border border-amber-800/40 rounded-xl shrink-0">
          <Layers className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-[10px] text-amber-300 font-medium">Fondo activo</div>
            <div className="text-[9px] text-amber-500/70 truncate">{bgMedia.name}</div>
          </div>
          <button
            onClick={onClearBgMedia}
            className="p-1 hover:bg-amber-800/40 rounded text-amber-500 hover:text-amber-200 transition-colors">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Drop zone */}
      <div
        className="mx-2 mt-2 border-2 border-dashed border-zinc-700 rounded-xl p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-amber-600/50 hover:bg-amber-950/10 transition-colors shrink-0"
        onClick={() => fileRef.current?.click()}
        onDragOver={e => { e.preventDefault(); e.currentTarget.classList.add('border-amber-500', 'bg-amber-950/20'); }}
        onDragLeave={e => { e.currentTarget.classList.remove('border-amber-500', 'bg-amber-950/20'); }}
        onDrop={e => {
          e.preventDefault();
          e.currentTarget.classList.remove('border-amber-500', 'bg-amber-950/20');
          handleFiles(e.dataTransfer.files);
        }}
      >
        {loading
          ? <div className="text-xs text-zinc-500">Procesando…</div>
          : <>
              <Upload className="w-5 h-5 text-zinc-600" />
              <span className="text-xs text-zinc-500 text-center leading-relaxed">
                Arrastra imágenes o videos<br />o haz clic para seleccionar
              </span>
            </>
        }
        <input
          ref={fileRef}
          type="file"
          multiple
          accept="image/*,video/*"
          className="hidden"
          onChange={e => handleFiles(e.target.files)} />
      </div>

      {/* Legend */}
      {mediaLibrary.length > 0 && (
        <div className="flex items-center gap-3 px-3 pt-2 pb-0.5 shrink-0">
          <span className="text-[9px] uppercase tracking-wider text-zinc-600">{mediaLibrary.length} archivo{mediaLibrary.length !== 1 ? 's' : ''}</span>
          <div className="flex items-center gap-1 text-[9px] text-zinc-600">
            <div className="w-2 h-2 rounded-full bg-amber-500" />
            Fondo activo
          </div>
        </div>
      )}

      {/* Grid */}
      <div className="flex-1 overflow-y-auto min-h-0 p-2">
        {mediaLibrary.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-zinc-700 gap-2">
            <ImageIcon className="w-10 h-10 text-zinc-800" />
            <div className="text-xs text-center">Sin medios cargados</div>
            <div className="text-[10px] text-zinc-700 text-center">Sube imágenes o videos para usar como fondo o enviar en vivo</div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {mediaLibrary.map(item => (
              <MediaThumb
                key={item.id}
                item={item}
                isActiveBg={bgMedia?.id === item.id}
                onSendToLive={onSendToLive}
                onSetBg={onSetBgMedia}
                onClearBg={onClearBgMedia}
                onDelete={id => setMediaLibrary(p => p.filter(m => m.id !== id))}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
