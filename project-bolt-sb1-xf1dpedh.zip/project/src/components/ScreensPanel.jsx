import React, { useState, useEffect } from 'react';
import { Monitor, ExternalLink, Timer, Clock, CircleStop as StopCircle, Play } from 'lucide-react';

const SCREENS = [
  { id: 'live',       label: 'Pantalla principal',  desc: 'Audiencia · pantalla completa',    path: '/live',       color: 'text-red-400',     dot: 'bg-red-500' },
  { id: 'stage',      label: 'Pantalla de escenario', desc: 'Predicador · vista doble + reloj', path: '/stage',      color: 'text-amber-400',   dot: 'bg-amber-500' },
  { id: 'confidence', label: 'Monitor de confianza', desc: 'Letra grande · alto contraste',   path: '/confidence', color: 'text-emerald-400', dot: 'bg-emerald-500' },
  { id: 'operator',   label: 'Pantalla operador',    desc: 'Consola principal de control',    path: '/',           color: 'text-blue-400',    dot: 'bg-blue-500' },
];

function pad(n) { return String(n).padStart(2, '0'); }

function ServiceTimer({ startMs, running }) {
  const [elapsed, setElapsed] = useState(startMs ? Date.now() - startMs : 0);
  useEffect(() => {
    if (!running || !startMs) return;
    const t = setInterval(() => setElapsed(Date.now() - startMs), 1000);
    return () => clearInterval(t);
  }, [running, startMs]);
  const s = Math.floor(elapsed / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  return <span className="font-mono text-lg text-zinc-100">{pad(h)}:{pad(m % 60)}:{pad(s % 60)}</span>;
}

export default function ScreensPanel({
  serviceStartMs, setServiceStartMs,
  countdownEndsAt, setCountdownEndsAt,
}) {
  const [countdownMinutes, setCountdownMinutes] = useState('5');
  const serviceRunning = !!serviceStartMs;

  function openScreen(path) {
    const base = window.location.origin;
    window.open(base + path, '_blank', 'noopener');
  }

  function startService() {
    setServiceStartMs(Date.now());
  }
  function stopService() {
    setServiceStartMs(null);
  }

  function startCountdown() {
    const mins = parseFloat(countdownMinutes) || 5;
    setCountdownEndsAt(Date.now() + mins * 60 * 1000);
  }
  function stopCountdown() {
    setCountdownEndsAt(null);
  }

  const countdownActive = countdownEndsAt && countdownEndsAt > Date.now();

  return (
    <div className="flex-1 flex flex-col overflow-hidden min-h-0">
      <div className="flex-1 overflow-y-auto p-3 space-y-4 min-h-0">

        {/* Screen outputs */}
        <div>
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5">
            <Monitor className="w-3 h-3" /> Pantallas de salida
          </div>
          <div className="space-y-1.5">
            {SCREENS.map(s => (
              <div key={s.id} className="flex items-center gap-2 p-2.5 bg-zinc-950 border border-zinc-800 rounded-xl hover:border-zinc-700 transition-colors">
                <div className={`w-1.5 h-1.5 rounded-full ${s.dot} shrink-0`} />
                <div className="flex-1 min-w-0">
                  <div className={`text-xs font-medium ${s.color}`}>{s.label}</div>
                  <div className="text-[10px] text-zinc-600">{s.desc}</div>
                </div>
                <button
                  onClick={() => openScreen(s.path)}
                  className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors">
                  <ExternalLink className="w-3 h-3" /> Abrir
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Service timer */}
        <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5">
            <Clock className="w-3 h-3" /> Tiempo de servicio
          </div>
          <div className="flex items-center justify-between mb-2">
            {serviceRunning
              ? <ServiceTimer startMs={serviceStartMs} running />
              : <span className="font-mono text-lg text-zinc-600">00:00:00</span>
            }
            {serviceRunning
              ? (
                <button onClick={stopService}
                  className="flex items-center gap-1 text-[11px] px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-red-900/50 text-zinc-300 hover:text-red-300 transition-colors">
                  <StopCircle className="w-3.5 h-3.5" /> Detener
                </button>
              ) : (
                <button onClick={startService}
                  className="flex items-center gap-1 text-[11px] px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white transition-colors">
                  <Play className="w-3.5 h-3.5 fill-current" /> Iniciar
                </button>
              )
            }
          </div>
          <div className="text-[9px] text-zinc-700">Se muestra en la pantalla de escenario</div>
        </div>

        {/* Countdown timer */}
        <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 mb-2 flex items-center gap-1.5">
            <Timer className="w-3 h-3" /> Cuenta regresiva
          </div>
          <div className="flex items-center gap-2 mb-2">
            <input
              type="number"
              value={countdownMinutes}
              onChange={e => setCountdownMinutes(e.target.value)}
              min="1" max="60"
              className="w-16 bg-zinc-800 border border-zinc-700 rounded-lg text-sm px-2 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 font-mono text-center" />
            <span className="text-xs text-zinc-500">minutos</span>
          </div>
          {countdownActive
            ? (
              <button onClick={stopCountdown}
                className="w-full flex items-center justify-center gap-1.5 text-[11px] py-1.5 rounded-lg bg-zinc-800 hover:bg-red-900/50 text-zinc-300 hover:text-red-300 transition-colors">
                <StopCircle className="w-3.5 h-3.5" /> Cancelar cuenta regresiva
              </button>
            ) : (
              <button onClick={startCountdown}
                className="w-full flex items-center justify-center gap-1.5 text-[11px] py-1.5 rounded-lg bg-amber-700 hover:bg-amber-600 text-white transition-colors font-medium">
                <Timer className="w-3.5 h-3.5" /> Iniciar cuenta regresiva
              </button>
            )
          }
          <div className="text-[9px] text-zinc-700 mt-1">Se muestra en la pantalla de escenario</div>
        </div>

      </div>
    </div>
  );
}
