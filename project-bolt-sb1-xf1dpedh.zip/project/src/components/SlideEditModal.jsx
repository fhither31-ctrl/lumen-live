import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

export default function SlideEditModal({ slide, onSave, onClose }) {
  const [label,  setLabel]  = useState(slide.label  || '');
  const [title,  setTitle]  = useState(slide.title  || '');
  const [lyrics, setLyrics] = useState(slide.lyrics || '');

  useEffect(() => {
    const onKey = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl w-full max-w-lg">
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800">
          <h2 className="text-sm font-semibold text-zinc-100">Editar slide</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-5 space-y-3">
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Etiqueta</label>
              <input value={label} onChange={e => setLabel(e.target.value)} autoFocus
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
            <div className="flex-1">
              <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Título</label>
              <input value={title} onChange={e => setTitle(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors" />
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Letra</label>
            <textarea value={lyrics} onChange={e => setLyrics(e.target.value)} rows={5}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500 resize-none font-mono leading-relaxed transition-colors" />
          </div>
        </div>
        <div className="flex justify-end gap-2 px-5 py-3 border-t border-zinc-800">
          <button onClick={onClose} className="text-sm px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors">Cancelar</button>
          <button onClick={() => onSave({ ...slide, label, title, lyrics })}
            className="text-sm px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium transition-colors">
            Guardar
          </button>
        </div>
      </div>
    </div>
  );
}
