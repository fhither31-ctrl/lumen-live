import React from 'react';
import { Plus, CreditCard as Edit3, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';

const LABEL_COLORS = {
  'Verso':  'bg-blue-900/60 text-blue-300',
  'Verse':  'bg-blue-900/60 text-blue-300',
  'Coro':   'bg-amber-900/60 text-amber-300',
  'Chorus': 'bg-amber-900/60 text-amber-300',
  'Puente': 'bg-emerald-900/60 text-emerald-300',
  'Bridge': 'bg-emerald-900/60 text-emerald-300',
  'Intro':  'bg-zinc-700/80 text-zinc-300',
  'Outro':  'bg-zinc-700/80 text-zinc-300',
};

function getLabelColor(label) {
  if (!label) return 'bg-zinc-800 text-zinc-400';
  const key = Object.keys(LABEL_COLORS).find(k => label.toLowerCase().startsWith(k.toLowerCase()));
  return key ? LABEL_COLORS[key] : 'bg-zinc-800 text-zinc-400';
}

function SlideThumbnail({ slide, theme, index, isLive, isActive, onClick, onEdit, onDelete, onMoveLeft, onMoveRight, isFirst, isLast }) {
  const lines = slide?.lyrics ? slide.lyrics.split('\n').filter(Boolean) : [];

  return (
    <div
      onClick={onClick}
      className={`group relative aspect-video rounded-lg overflow-hidden cursor-pointer select-none
        border-2 transition-all duration-150 ease-out
        ${isLive
          ? 'border-red-500 shadow-[0_0_0_3px_rgba(239,68,68,0.2),0_4px_20px_rgba(239,68,68,0.15)] scale-[1.02]'
          : isActive
            ? 'border-amber-500 shadow-[0_0_0_2px_rgba(245,158,11,0.2)]'
            : 'border-zinc-800 hover:border-zinc-500 hover:shadow-[0_2px_12px_rgba(0,0,0,0.4)]'
        }`}
    >
      {/* Background + text */}
      <div className={`absolute inset-0 ${theme.bgClass} flex items-center justify-center p-3 transition-colors duration-300`}>
        <div className={`text-center ${theme.textClass} ${theme.fontClass}`}>
          {slide?.title && (
            <div className="text-[8px] uppercase tracking-widest opacity-60 mb-1">{slide.title}</div>
          )}
          {lines.slice(0, 3).map((line, i) => (
            <div key={i} className="text-[9px] leading-snug">{line}</div>
          ))}
          {lines.length > 3 && <div className="text-[8px] opacity-40 mt-0.5">…</div>}
        </div>
      </div>

      {/* Top-left: label */}
      <div className={`absolute top-1.5 left-1.5 text-[8px] uppercase tracking-wide px-1.5 py-0.5 rounded font-medium ${getLabelColor(slide?.label)}`}>
        {slide?.label || '—'}
      </div>

      {/* Top-right: LIVE badge */}
      {isLive && (
        <div className="absolute top-1.5 right-1.5 flex items-center gap-1 text-[8px] uppercase px-1.5 py-0.5 bg-red-600 rounded font-semibold text-white">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />VIVO
        </div>
      )}

      {/* Bottom-right: slide number */}
      <div className="absolute bottom-1.5 right-1.5 text-[9px] text-white/50 bg-black/40 px-1.5 py-0.5 rounded">
        {index + 1}
      </div>

      {/* Hover action bar */}
      <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-0.5 py-1.5 px-2
        opacity-0 group-hover:opacity-100 transition-opacity duration-150
        bg-gradient-to-t from-black/90 via-black/60 to-transparent">
        <button
          onClick={e => { e.stopPropagation(); onEdit(); }}
          className="p-1 rounded bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors"
          title="Editar">
          <Edit3 className="w-3 h-3" />
        </button>
        <button
          onClick={e => { e.stopPropagation(); onMoveLeft(); }}
          disabled={isFirst}
          className="p-1 rounded bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors disabled:opacity-20 disabled:cursor-not-allowed"
          title="Mover izquierda">
          <ChevronLeft className="w-3 h-3" />
        </button>
        <button
          onClick={e => { e.stopPropagation(); onMoveRight(); }}
          disabled={isLast}
          className="p-1 rounded bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors disabled:opacity-20 disabled:cursor-not-allowed"
          title="Mover derecha">
          <ChevronRight className="w-3 h-3" />
        </button>
        <button
          onClick={e => { e.stopPropagation(); onDelete(); }}
          className="p-1 rounded bg-white/10 hover:bg-red-600/80 text-white/80 hover:text-white transition-colors"
          title="Eliminar">
          <Trash2 className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}

export default function SlideGrid({
  item, activeSetlistIdx, liveSetlistIdx, liveSlideIdx, activeSlideIdx, isLive,
  theme, onSlideClick, onEditSlide, onDeleteSlide, onMoveSlide, onAddSlide,
}) {
  if (!item) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 text-zinc-700">
        <div className="w-16 h-16 rounded-2xl border-2 border-dashed border-zinc-800 flex items-center justify-center">
          <Plus className="w-7 h-7 text-zinc-700" />
        </div>
        <div className="text-sm text-zinc-600">Selecciona un canto del servicio</div>
        <div className="text-xs text-zinc-700">o agrega uno desde la biblioteca</div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="grid grid-cols-3 xl:grid-cols-4 gap-3 p-4">
        {item.slides.map((slide, i) => (
          <SlideThumbnail
            key={slide.id || i}
            slide={slide}
            theme={theme}
            index={i}
            isLive={liveSetlistIdx === activeSetlistIdx && liveSlideIdx === i && isLive}
            isActive={activeSlideIdx === i}
            onClick={() => onSlideClick(i)}
            onEdit={() => onEditSlide(i, slide)}
            onDelete={() => onDeleteSlide(i)}
            onMoveLeft={() => onMoveSlide(i, -1)}
            onMoveRight={() => onMoveSlide(i, 1)}
            isFirst={i === 0}
            isLast={i === item.slides.length - 1}
          />
        ))}

        {/* Add slide card */}
        <button
          onClick={onAddSlide}
          className="aspect-video rounded-lg border-2 border-dashed border-zinc-800 hover:border-zinc-600 flex flex-col items-center justify-center gap-1.5 text-zinc-700 hover:text-zinc-400 transition-colors">
          <Plus className="w-5 h-5" />
          <span className="text-[10px] uppercase tracking-wide">Nuevo slide</span>
        </button>
      </div>
    </div>
  );
}
