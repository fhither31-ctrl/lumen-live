import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, ChevronUp, ChevronDown } from 'lucide-react';
import { uid, CATEGORIES } from '../store';

export default function SongModal({ song, onSave, onClose }) {
  const isNew = !song;
  const [title, setTitle]       = useState(song?.title    || '');
  const [author, setAuthor]     = useState(song?.author   || '');
  const [category, setCategory] = useState(song?.category || CATEGORIES[0]);
  const [slides, setSlides]     = useState(
    song?.slides?.length
      ? song.slides.map(s => ({ ...s }))
      : [{ id: uid(), label: 'Verso 1', title: '', lyrics: '' }]
  );
  const [activeSl, setActiveSl] = useState(0);

  useEffect(() => {
    const onKey = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  function addSlide() {
    const next = [...slides, { id: uid(), label: 'Verso', title: '', lyrics: '' }];
    setSlides(next);
    setActiveSl(next.length - 1);
  }
  function removeSlide(i) {
    if (slides.length === 1) return;
    const next = slides.filter((_, idx) => idx !== i);
    setSlides(next);
    setActiveSl(Math.min(activeSl, next.length - 1));
  }
  function updateSlide(i, field, value) {
    setSlides(prev => prev.map((s, idx) => idx === i ? { ...s, [field]: value } : s));
  }
  function moveSlide(i, dir) {
    const j = i + dir;
    if (j < 0 || j >= slides.length) return;
    const next = [...slides];
    [next[i], next[j]] = [next[j], next[i]];
    setSlides(next);
    setActiveSl(j);
  }
  function handleSave() {
    if (!title.trim()) return;
    onSave({ id: song?.id || uid(), title: title.trim(), author: author.trim(), category, slides });
  }

  const cur = slides[activeSl];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl w-full max-w-3xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-zinc-800">
          <h2 className="text-sm font-semibold text-zinc-100">{isNew ? 'Nuevo canto' : 'Editar canto'}</h2>
          <button onClick={onClose} className="p-1.5 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 flex overflow-hidden min-h-0">
          {/* Left: meta + slide list */}
          <div className="w-52 border-r border-zinc-800 flex flex-col p-4 gap-3 shrink-0 overflow-y-auto">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Título *</label>
              <input value={title} onChange={e => setTitle(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors"
                placeholder="Título del canto" autoFocus />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Autor</label>
              <input value={author} onChange={e => setAuthor(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors"
                placeholder="Nombre del autor" />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Categoría</label>
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500">
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            <div className="pt-1">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[10px] uppercase tracking-wider text-zinc-500">Slides ({slides.length})</label>
                <button onClick={addSlide} className="p-1 hover:bg-zinc-700 rounded text-zinc-400 hover:text-amber-400 transition-colors">
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-0.5">
                {slides.map((s, i) => (
                  <div key={s.id}
                    onClick={() => setActiveSl(i)}
                    className={`group flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer text-xs transition-colors ${
                      activeSl === i
                        ? 'bg-amber-950/50 text-amber-300 border border-amber-800/50'
                        : 'text-zinc-400 hover:bg-zinc-800 border border-transparent'
                    }`}>
                    <span className="flex-1 truncate">{s.label || `Slide ${i + 1}`}</span>
                    <div className="flex gap-0.5 opacity-0 group-hover:opacity-100">
                      <button onClick={e => { e.stopPropagation(); moveSlide(i, -1); }} disabled={i === 0}
                        className="p-0.5 hover:text-zinc-100 disabled:opacity-20"><ChevronUp className="w-3 h-3" /></button>
                      <button onClick={e => { e.stopPropagation(); moveSlide(i, 1); }} disabled={i === slides.length - 1}
                        className="p-0.5 hover:text-zinc-100 disabled:opacity-20"><ChevronDown className="w-3 h-3" /></button>
                      <button onClick={e => { e.stopPropagation(); removeSlide(i); }} disabled={slides.length === 1}
                        className="p-0.5 hover:text-red-400 disabled:opacity-20"><Trash2 className="w-3 h-3" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: slide editor */}
          {cur && (
            <div className="flex-1 p-4 flex flex-col gap-3 overflow-y-auto min-h-0">
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Etiqueta</label>
                  <input value={cur.label} onChange={e => updateSlide(activeSl, 'label', e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors"
                    placeholder="Verso 1, Coro, Puente…" />
                </div>
                <div className="flex-1">
                  <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Título (opcional)</label>
                  <input value={cur.title} onChange={e => updateSlide(activeSl, 'title', e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-1.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors"
                    placeholder="Texto pequeño encima" />
                </div>
              </div>
              <div className="flex-1">
                <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Letra</label>
                <textarea value={cur.lyrics} onChange={e => updateSlide(activeSl, 'lyrics', e.target.value)}
                  rows={6}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg text-sm px-3 py-2 text-zinc-100 focus:outline-none focus:border-amber-500 resize-none font-mono leading-relaxed transition-colors"
                  placeholder="Una línea por verso…" />
              </div>
              {/* Mini preview */}
              <div>
                <label className="text-[10px] uppercase tracking-wider text-zinc-500 mb-1 block">Vista previa</label>
                <div className="aspect-video rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center p-4 overflow-hidden">
                  <div className="text-center">
                    {cur.title && <div className="text-[10px] text-amber-400/70 uppercase tracking-widest mb-1">{cur.title}</div>}
                    {cur.lyrics.split('\n').filter(Boolean).map((line, i) => (
                      <div key={i} className="font-serif text-sm text-zinc-200 leading-snug">{line}</div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-zinc-800">
          <button onClick={onClose} className="text-sm px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors">Cancelar</button>
          <button onClick={handleSave} disabled={!title.trim()}
            className="text-sm px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
            {isNew ? 'Crear canto' : 'Guardar cambios'}
          </button>
        </div>
      </div>
    </div>
  );
}
