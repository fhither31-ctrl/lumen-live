import { StrictMode } from 'react';
import { createRoot }  from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './index.css';
import App              from './App.jsx';
import LiveScreen       from './screens/LiveScreen.jsx';
import StageScreen      from './screens/StageScreen.jsx';
import ConfidenceScreen from './screens/ConfidenceScreen.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/"           element={<App />} />
        <Route path="/operator"   element={<App />} />
        <Route path="/live"       element={<LiveScreen />} />
        <Route path="/stage"      element={<StageScreen />} />
        <Route path="/confidence" element={<ConfidenceScreen />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
