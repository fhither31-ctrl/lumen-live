import React, { useState, useEffect, useRef } from 'react';
import { subscribeLive, readLiveState, requestLiveState } from '../store';

// High-contrast confidence monitor — maximum legibility for the speaker.
// No theme colors — always white on black for maximum readability.
export default function ConfidenceScreen() {
  const [state, setState] = useState(() => readLiveState());
  const [animKey, setAnimKey] = useState(0);
  const prevRef = useRef(null);

  useEffect(() => {
    requestLiveState();
    const unsub = subscribeLive((payload) => setState(payload));
    return unsub;
  }, []);

  useEffect(() => {
    const id = state?.slide?.id ?? state?.slide?.lyrics;
    if (id !== prevRef.current) { setAnimKey(k => k + 1); prevRef.current = id; }
  }, [state?.slide]);

  const isLive  = state?.isLive;
  const mode    = state?.outputMode ?? 'logo';
  const lines   = state?.slide?.lyrics?.split('\n').filter(Boolean) ?? [];
  const nLines  = state?.nextSlide?.lyrics?.split('\n').filter(Boolean) ?? [];

  // Font size scales with number of lines
  const mainSize = lines.length <= 1 ? '7rem' : lines.length === 2 ? '5.5rem' : lines.length === 3 ? '4.5rem' : '3.5rem';

  return (
    <div className="w-screen h-screen bg-black text-white flex flex-col overflow-hidden">
      {/* Status strip */}
      <div className="h-8 shrink-0 bg-zinc-950 border-b border-zinc-900 flex items-center justify-between px-6">
        <div className="flex items-center gap-2.5">
          <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-red-500 animate-pulse' : 'bg-zinc-800'}`} />
          <span className="text-[10px] uppercase tracking-[0.25em] text-zinc-600">
            {isLive ? 'Monitor de Confianza · En Vivo' : 'Monitor de Confianza · En espera'}
          </span>
        </div>
        {isLive && state?.slideNum != null && (
          <span className="text-[10px] font-mono text-zinc-700">
            {state.slideNum} / {state.totalSlides}
          </span>
        )}
      </div>

      {/* ── Idle / black states ── */}
      {(!isLive || mode === 'logo') && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="font-serif text-7xl text-zinc-800 mb-4">Lumen Live</div>
            <div className="text-sm uppercase tracking-[0.3em] text-zinc-800">Monitor de Confianza</div>
          </div>
        </div>
      )}

      {isLive && mode === 'black' && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-zinc-800 text-2xl uppercase tracking-[0.3em]">Pantalla Negra</div>
        </div>
      )}

      {isLive && mode === 'clear' && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-zinc-800 text-2xl uppercase tracking-[0.3em]">Pantalla Limpia</div>
        </div>
      )}

      {/* ── Active slide content ── */}
      {isLive && (mode === 'slide' || mode === 'media') && (
        <div className="flex-1 flex flex-col min-h-0">
          {/* Label + current lyrics */}
          <div className="flex-1 flex flex-col items-center justify-center px-12 py-6 min-h-0">
            {state?.slide?.label && (
              <div className="text-sm uppercase tracking-[0.35em] text-zinc-600 mb-5 self-start">
                {state.slide.label}
                {state?.title && <span className="text-zinc-700 ml-3">· {state.title}</span>}
              </div>
            )}
            <div key={animKey} style={{ animation: 'confidenceFadeIn 200ms ease-out' }} className="w-full">
              {lines.map((line, i) => (
                <div
                  key={i}
                  className="font-bold text-white leading-tight text-center"
                  style={{ fontSize: mainSize, lineHeight: 1.15 }}
                >
                  {line}
                </div>
              ))}
              {lines.length === 0 && (
                <div className="text-zinc-800 text-4xl text-center">—</div>
              )}
            </div>
          </div>

          {/* Next slide preview strip */}
          <div className="shrink-0 border-t-2 border-zinc-900 bg-zinc-950">
            <div className="px-10 py-4">
              <div className="text-[10px] uppercase tracking-[0.3em] text-zinc-700 mb-2">
                A continuación
                {state?.nextSlide?.label && <span className="text-zinc-700 ml-2">· {state.nextSlide.label}</span>}
              </div>
              {nLines.length > 0
                ? nLines.slice(0, 2).map((line, i) => (
                  <div key={i} className="text-2xl font-semibold text-zinc-500 leading-snug">{line}</div>
                ))
                : <div className="text-zinc-800 text-lg">— fin del servicio —</div>
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
