import React, { useState, useEffect, useRef } from 'react';
import { subscribeLive, readLiveState, requestLiveState, defaultThemes } from '../store';

// Full-screen audience display. No chrome. Syncs via BroadcastChannel.
export default function LiveScreen() {
  const [state,   setState]   = useState(() => readLiveState());
  const [animKey, setAnimKey] = useState(0);
  const [frozen,  setFrozen]  = useState(null);
  const prevIdRef = useRef(null);

  useEffect(() => {
    requestLiveState();
    const unsub = subscribeLive((payload) => {
      setState(payload);
      if (payload.isFrozen) {
        setFrozen(prev => prev ?? payload);
      } else {
        setFrozen(null);
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    const id = state?.slide?.id ?? state?.slide?.lyrics;
    if (id !== prevIdRef.current) {
      if (!state?.isFrozen) setAnimKey(k => k + 1);
      prevIdRef.current = id;
    }
  }, [state?.slide, state?.isFrozen]);

  const display = frozen ?? state;
  const theme   = defaultThemes.find(t => t.id === display?.themeId) ?? defaultThemes[1];
  const mode    = display?.outputMode ?? 'logo';
  const lines   = display?.slide?.lyrics?.split('\n').filter(Boolean) ?? [];
  const bg      = display?.bgMedia ?? null;

  // ── Black ──────────────────────────────────────────────────────────────────
  if (mode === 'black') return <div className="w-screen h-screen bg-black" />;

  // ── Clear ──────────────────────────────────────────────────────────────────
  if (mode === 'clear') return <div className="w-screen h-screen bg-transparent" />;

  // ── Media (full-screen, no lyrics) ────────────────────────────────────────
  if (mode === 'media' && display?.media?.url) {
    const m = display.media;
    return (
      <div className="w-screen h-screen bg-black flex items-center justify-center overflow-hidden">
        {m.type === 'video'
          ? <video src={m.url} className="w-full h-full object-contain" autoPlay loop muted playsInline />
          : <img   src={m.url} alt=""  className="w-full h-full object-contain" />
        }
      </div>
    );
  }

  // ── Logo / idle ────────────────────────────────────────────────────────────
  if (mode === 'logo' || !display?.isLive || !display?.slide) {
    return (
      <div className="w-screen h-screen bg-zinc-950 flex items-center justify-center">
        {bg && <BgLayer media={bg} />}
        <div className="relative z-10 flex flex-col items-center gap-5 opacity-50">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center shadow-2xl">
            <div className="w-14 h-14 rounded-full bg-zinc-950" />
          </div>
          <div className="text-center">
            <div className="font-serif text-6xl text-zinc-200 tracking-tight">Lumen</div>
            <div className="text-sm uppercase tracking-[0.4em] text-amber-500/60 mt-2">Live</div>
          </div>
        </div>
      </div>
    );
  }

  // ── Slide with optional background ────────────────────────────────────────
  const hasBg = !!bg;
  // When a background is active, darken the theme bg and add text-shadow for readability
  return (
    <div className={`w-screen h-screen overflow-hidden relative flex items-center justify-center ${hasBg ? 'bg-black' : theme.bgClass}`}>

      {/* Background media layer */}
      {hasBg && <BgLayer media={bg} />}

      {/* Scrim — darkens bg so text stays readable */}
      {hasBg && <div className="absolute inset-0 bg-black/50 z-10" />}

      {/* Slide text */}
      <div
        key={animKey}
        className="relative z-20 text-center px-16 max-w-5xl animate-crossFade"
      >
        {display.slide.title && (
          <div
            className={`text-base uppercase tracking-[0.35em] mb-6 opacity-80 ${hasBg ? 'text-white' : theme.textClass} ${theme.fontClass}`}
            style={hasBg ? { textShadow: '0 2px 12px rgba(0,0,0,0.9)' } : undefined}
          >
            {display.slide.title}
          </div>
        )}
        {lines.map((line, i) => (
          <div
            key={i}
            className={`font-serif leading-tight mb-3 ${hasBg ? 'text-white' : theme.textClass}`}
            style={{
              fontSize:   lines.length <= 2 ? '5.5rem' : lines.length <= 3 ? '4.5rem' : '3.5rem',
              textShadow: hasBg ? '0 2px 24px rgba(0,0,0,1), 0 0 60px rgba(0,0,0,0.8)' : undefined,
            }}
          >
            {line}
          </div>
        ))}
        {display.slide.label && (
          <div
            className={`text-sm uppercase tracking-[0.3em] mt-8 opacity-40 ${hasBg ? 'text-white' : theme.textClass} ${theme.fontClass}`}
            style={hasBg ? { textShadow: '0 1px 8px rgba(0,0,0,0.9)' } : undefined}
          >
            {display.slide.label}
          </div>
        )}
      </div>
    </div>
  );
}

// Renders a looping video or image as a full-screen background
function BgLayer({ media }) {
  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      {media.type === 'video' ? (
        <video
          key={media.id}
          src={media.url}
          className="w-full h-full object-cover"
          autoPlay
          loop
          muted
          playsInline
        />
      ) : (
        <img
          key={media.id}
          src={media.url}
          alt=""
          className="w-full h-full object-cover"
        />
      )}
    </div>
  );
}
