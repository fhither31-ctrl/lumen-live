// The operator screen is just the main App — this file is a re-export
// It exists so /operator can render the same App component as the root.
export { default } from '../App';
