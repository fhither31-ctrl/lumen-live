import React, { useState, useEffect, useRef } from 'react';
import { subscribeLive, readLiveState, requestLiveState, defaultThemes } from '../store';

// ── Clocks & timers ───────────────────────────────────────────────────────────

function pad(n) { return String(Math.max(0, n)).padStart(2, '0'); }

function WallClock() {
  const [t, setT] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setT(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span>
      {pad(t.getHours())}:{pad(t.getMinutes())}:{pad(t.getSeconds())}
    </span>
  );
}

function ServiceTimer({ startMs }) {
  const [elapsed, setElapsed] = useState(startMs ? Date.now() - startMs : 0);
  useEffect(() => {
    if (!startMs) { setElapsed(0); return; }
    setElapsed(Date.now() - startMs);
    const id = setInterval(() => setElapsed(Date.now() - startMs), 1000);
    return () => clearInterval(id);
  }, [startMs]);
  const s = Math.floor(elapsed / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  return <span>{pad(h)}:{pad(m % 60)}:{pad(s % 60)}</span>;
}

function Countdown({ endsAt }) {
  const [rem, setRem] = useState(Math.max(0, (endsAt ?? 0) - Date.now()));
  useEffect(() => {
    if (!endsAt) { setRem(0); return; }
    setRem(Math.max(0, endsAt - Date.now()));
    const id = setInterval(() => setRem(Math.max(0, endsAt - Date.now())), 500);
    return () => clearInterval(id);
  }, [endsAt]);
  const s = Math.ceil(rem / 1000);
  const m = Math.floor(s / 60);
  const urgent = s > 0 && s <= 30;
  return (
    <div className={`font-mono text-2xl font-bold ${urgent ? 'text-red-400 animate-pulse' : 'text-amber-400'}`}>
      {pad(m)}:{pad(s % 60)}
    </div>
  );
}

// ── Slide box ─────────────────────────────────────────────────────────────────

function SlideBox({ slide, theme, textSize = 'text-3xl', dimmed = false, label }) {
  const lines = slide?.lyrics?.split('\n').filter(Boolean) ?? [];
  return (
    <div className={`relative w-full h-full rounded-2xl overflow-hidden transition-opacity duration-300 ${dimmed ? 'opacity-40' : 'opacity-100'}`}>
      <div className={`absolute inset-0 ${theme.bgClass}`} />
      <div className="absolute inset-0 flex flex-col items-center justify-center px-8">
        {label && (
          <div className={`text-xs uppercase tracking-[0.3em] mb-3 opacity-50 ${theme.textClass}`}>{label}</div>
        )}
        {slide?.title && (
          <div className={`text-sm uppercase tracking-widest opacity-60 mb-2 ${theme.textClass}`}>{slide.title}</div>
        )}
        {lines.length > 0
          ? lines.map((line, i) => (
            <div key={i} className={`${textSize} font-serif leading-snug text-center ${theme.textClass}`}>{line}</div>
          ))
          : <div className={`text-2xl opacity-20 ${theme.textClass}`}>—</div>
        }
        {slide?.label && !label && (
          <div className={`text-[10px] uppercase tracking-[0.3em] mt-4 opacity-30 ${theme.textClass}`}>{slide.label}</div>
        )}
      </div>
    </div>
  );
}

// ── Main stage screen ─────────────────────────────────────────────────────────

export default function StageScreen() {
  const [state, setState] = useState(() => readLiveState());
  const [animKey, setAnimKey] = useState(0);
  const prevRef = useRef(null);

  useEffect(() => {
    requestLiveState();
    const unsub = subscribeLive((payload) => setState(payload));
    return unsub;
  }, []);

  useEffect(() => {
    const id = state?.slide?.id ?? state?.slide?.lyrics;
    if (id !== prevRef.current) { setAnimKey(k => k + 1); prevRef.current = id; }
  }, [state?.slide]);

  const theme  = defaultThemes.find(t => t.id === state?.themeId) ?? defaultThemes[1];
  const isLive = state?.isLive;
  const mode   = state?.outputMode ?? 'logo';

  return (
    <div className="w-screen h-screen bg-zinc-950 text-zinc-100 flex flex-col overflow-hidden">

      {/* ── Top status bar ── */}
      <div className="h-12 shrink-0 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between px-5">
        {/* Left: live indicator + song title */}
        <div className="flex items-center gap-3">
          <div className={`w-2.5 h-2.5 rounded-full ${isLive ? 'bg-red-500 animate-pulse' : 'bg-zinc-700'}`} />
          <div>
            <span className="text-xs font-semibold text-zinc-300">
              {isLive ? (state?.title || 'En Vivo') : 'Pantalla de Escenario'}
            </span>
            {isLive && state?.slideNum != null && (
              <span className="text-[10px] text-zinc-600 ml-2">
                {state.slideNum} / {state.totalSlides}
              </span>
            )}
          </div>
        </div>

        {/* Center: timers */}
        <div className="flex items-center gap-6 font-mono text-sm">
          {state?.serviceStartMs && (
            <div className="flex items-center gap-2 text-zinc-400">
              <span className="text-[9px] uppercase tracking-widest text-zinc-600">Servicio</span>
              <ServiceTimer startMs={state.serviceStartMs} />
            </div>
          )}
          {state?.countdownEndsAt && state.countdownEndsAt > Date.now() && (
            <Countdown endsAt={state.countdownEndsAt} />
          )}
          <div className="flex items-center gap-2 text-zinc-400">
            <span className="text-[9px] uppercase tracking-widest text-zinc-600">Hora</span>
            <WallClock />
          </div>
        </div>

        {/* Right: slide label */}
        {isLive && state?.slide?.label && (
          <div className="text-xs text-zinc-500 bg-zinc-800 px-2.5 py-1 rounded-lg">
            {state.slide.label}
          </div>
        )}
      </div>

      {/* ── Black/logo states ── */}
      {(mode === 'black' || mode === 'clear' || !isLive) && (
        <div className="flex-1 flex items-center justify-center">
          {mode === 'black'
            ? <div className="text-zinc-700 text-xl uppercase tracking-widest">Pantalla Negra</div>
            : mode === 'clear'
              ? <div className="text-zinc-700 text-xl uppercase tracking-widest">Pantalla Limpia</div>
              : (
                <div className="text-center opacity-30">
                  <div className="font-serif text-5xl text-zinc-400 mb-3">Lumen Live</div>
                  <div className="text-sm uppercase tracking-widest text-zinc-600">Esperando…</div>
                </div>
              )
          }
        </div>
      )}

      {/* ── Main content: current + next ── */}
      {mode === 'slide' && isLive && (
        <div className="flex-1 flex flex-col p-4 gap-3 overflow-hidden min-h-0">
          {/* Current slide — takes ~65% */}
          <div className="flex-[65] min-h-0" key={animKey} style={{ animation: 'fadeSlide 250ms ease-out' }}>
            <SlideBox
              slide={state?.slide}
              theme={theme}
              textSize={state?.slide?.lyrics?.split('\n').filter(Boolean).length > 2 ? 'text-4xl' : 'text-5xl'}
              label="ACTUAL"
            />
          </div>

          {/* Next slide — takes ~35% */}
          <div className="flex-[35] min-h-0">
            <SlideBox
              slide={state?.nextSlide ?? null}
              theme={theme}
              textSize="text-2xl"
              dimmed
              label={state?.nextSlide ? 'A CONTINUACIÓN' : undefined}
            />
            {!state?.nextSlide && (
              <div className="w-full h-full rounded-2xl border-2 border-dashed border-zinc-800 flex items-center justify-center">
                <span className="text-zinc-700 text-sm">— fin del servicio —</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Media mode */}
      {mode === 'media' && state?.media?.url && (
        <div className="flex-1 flex items-center justify-center bg-black">
          <img src={state.media.url} alt="" className="max-w-full max-h-full object-contain" />
        </div>
      )}
    </div>
  );
}
