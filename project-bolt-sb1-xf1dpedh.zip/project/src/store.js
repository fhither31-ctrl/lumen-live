// ─── Storage keys ─────────────────────────────────────────────────────────────
const STORAGE_KEY  = 'lumen-live-v4';
const LIVE_KEY     = 'lumen-live-state';
const CHANNEL_NAME = 'lumen-sync';

// ─── Constants ────────────────────────────────────────────────────────────────
export const CATEGORIES = ['Adoración', 'Alabanza', 'Himnos', 'Coro', 'Especial', 'Biblia', 'Otro'];

export const defaultThemes = [
  { id: 't1', name: 'Noche',    bgClass: 'bg-zinc-950',                                                 textClass: 'text-white',      fontClass: 'font-serif', preview: '#09090b' },
  { id: 't2', name: 'Amanecer', bgClass: 'bg-gradient-to-br from-amber-900 via-orange-800 to-rose-900',  textClass: 'text-amber-50',   fontClass: 'font-serif', preview: 'linear-gradient(135deg,#78350f,#9a3412,#881337)' },
  { id: 't3', name: 'Océano',   bgClass: 'bg-gradient-to-br from-slate-900 via-blue-950 to-cyan-950',    textClass: 'text-blue-50',    fontClass: 'font-serif', preview: 'linear-gradient(135deg,#0f172a,#083344,#042f2e)' },
  { id: 't4', name: 'Bosque',   bgClass: 'bg-gradient-to-br from-emerald-950 via-green-900 to-teal-950', textClass: 'text-emerald-50', fontClass: 'font-serif', preview: 'linear-gradient(135deg,#022c22,#14532d,#042f2e)' },
  { id: 't5', name: 'Limpio',   bgClass: 'bg-stone-100',                                                 textClass: 'text-stone-900',  fontClass: 'font-sans',  preview: '#f5f5f4' },
  { id: 't6', name: 'Cielo',    bgClass: 'bg-gradient-to-br from-sky-900 via-sky-800 to-blue-900',       textClass: 'text-sky-50',     fontClass: 'font-serif', preview: 'linear-gradient(135deg,#0c4a6e,#0369a1,#1e3a8a)' },
  { id: 't7', name: 'Carbón',   bgClass: 'bg-gradient-to-br from-zinc-900 to-zinc-800',                  textClass: 'text-zinc-100',   fontClass: 'font-serif', preview: 'linear-gradient(135deg,#18181b,#27272a)' },
  { id: 't8', name: 'Vino',     bgClass: 'bg-gradient-to-br from-rose-950 via-red-950 to-stone-950',     textClass: 'text-rose-50',    fontClass: 'font-serif', preview: 'linear-gradient(135deg,#4c0519,#450a0a,#1c1917)' },
];

// ─── Default data ─────────────────────────────────────────────────────────────
const defaultSongs = [
  {
    id: 's1', title: 'Sublime Gracia', author: 'John Newton', category: 'Himnos',
    slides: [
      { id: 'sl1',  label: 'Verso 1', title: '', lyrics: 'Sublime gracia del Señor\nque a un infeliz salvó' },
      { id: 'sl2',  label: 'Verso 1', title: '', lyrics: 'Fui ciego mas hoy miro yo\nperdido y Él me halló' },
      { id: 'sl3',  label: 'Verso 2', title: '', lyrics: 'Su gracia me enseñó a temer\nmis dudas ahuyentó' },
      { id: 'sl4',  label: 'Verso 2', title: '', lyrics: '¡Oh cuán precioso fue a mi ser\ncuando Él me transformó!' },
    ],
  },
  {
    id: 's2', title: 'Santo, Santo, Santo', author: 'Reginald Heber', category: 'Adoración',
    slides: [
      { id: 'sl5',  label: 'Verso 1', title: '', lyrics: 'Santo, Santo, Santo\nSeñor Omnipotente' },
      { id: 'sl6',  label: 'Coro',    title: '', lyrics: 'Santo, Santo, Santo\nMisericordioso y fuerte' },
      { id: 'sl7',  label: 'Verso 2', title: '', lyrics: 'Santo, Santo, Santo\nTodos los santos te adoran' },
    ],
  },
  {
    id: 's3', title: 'Cuán Grande Es Él', author: 'Carl Boberg', category: 'Adoración',
    slides: [
      { id: 'sl8',  label: 'Verso 1', title: '', lyrics: 'Señor mi Dios al contemplar los cielos\nel firmamento y las estrellas mil' },
      { id: 'sl9',  label: 'Coro',    title: '', lyrics: 'Mi corazón entona la canción\n¡Cuán grande es Él! ¡Cuán grande es Él!' },
      { id: 'sl10', label: 'Verso 2', title: '', lyrics: 'Al contemplar los montes y los valles\ny escuchar el murmullo del riachuelo' },
      { id: 'sl11', label: 'Coro',    title: '', lyrics: 'Mi corazón entona la canción\n¡Cuán grande es Él! ¡Cuán grande es Él!' },
    ],
  },
  {
    id: 's4', title: 'Roca de la Eternidad', author: 'Augustus Toplady', category: 'Himnos',
    slides: [
      { id: 'sl12', label: 'Verso 1', title: '', lyrics: 'Roca de la eternidad\nfuiste abierta para mí' },
      { id: 'sl13', label: 'Verso 2', title: '', lyrics: 'Nada en mi mano traigo\nsimplemente a tu cruz me aferro' },
    ],
  },
  {
    id: 's5', title: 'Tu Fidelidad', author: 'Great Is Thy Faithfulness', category: 'Alabanza',
    slides: [
      { id: 'sl14', label: 'Verso 1', title: '', lyrics: 'Oh Dios eterno tu misericordia\nni una sombra de duda tendrá' },
      { id: 'sl15', label: 'Coro',    title: '', lyrics: 'Tu fidelidad, tu fidelidad\ngrande es tu fidelidad' },
      { id: 'sl16', label: 'Verso 2', title: '', lyrics: 'La primavera y el verano y el otoño\ne invierno también de tu mano vendrán' },
    ],
  },
];

// ─── Utilities ────────────────────────────────────────────────────────────────
export function uid() {
  return Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
}

// ─── App state persistence ────────────────────────────────────────────────────
// Saved shape (v4):
// {
//   songs, setlist,
//   activeThemeId, activeLibTab,
//   activeSetlistIdx, activeSlideIdx,
//   autoplayInterval,
//   serviceStartMs,          // null when not running; restored only if < 24h ago
//   mediaLibrary,            // array of { id, url, name, type }
// }

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function saveState(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}

export function getDefaultState() {
  return {
    songs:             defaultSongs,
    setlist:           [defaultSongs[0], defaultSongs[2]],
    activeThemeId:     't2',
    activeLibTab:      'songs',
    activeSetlistIdx:  0,
    activeSlideIdx:    0,
    autoplayInterval:  5,
    serviceStartMs:    null,
    mediaLibrary:      [],
  };
}

// ─── Live state cross-tab sync ────────────────────────────────────────────────
// Payload shape:
// {
//   isLive, outputMode,
//   slide: { id, label, title, lyrics },
//   nextSlide: { ... } | null,
//   themeId,
//   title,         // song title
//   slideNum,
//   totalSlides,
//   media: { url } | null,
//   serviceStartMs,
//   countdownEndsAt,
//   _ts,           // timestamp for dedup
// }

let _channel = null;
function getChannel() {
  if (!_channel) {
    try { _channel = new BroadcastChannel(CHANNEL_NAME); } catch {}
  }
  return _channel;
}

export function writeLiveState(state) {
  const payload = { ...state, _ts: Date.now() };
  // 1. Write to localStorage (persists state for new tabs opening after the fact)
  try { localStorage.setItem(LIVE_KEY, JSON.stringify(payload)); } catch {}
  // 2. Broadcast to all same-origin tabs instantly (no storage event polling needed)
  try { getChannel()?.postMessage(payload); } catch {}
}

// Called by the operator tab to re-broadcast current state when a screen tab requests it.
// Screen tabs call requestLiveState() on mount; operator tab calls this to respond.
export function respondToStateRequests(getCurrentState) {
  let ch = null;
  try {
    ch = new BroadcastChannel(CHANNEL_NAME + '-req');
    ch.onmessage = (e) => {
      if (e.data === 'REQUEST_STATE') {
        const state = getCurrentState();
        if (state) writeLiveState(state);
      }
    };
  } catch {}
  return () => { try { ch?.close(); } catch {} };
}

// Called by screen tabs on mount to ask the operator to re-send current state.
export function requestLiveState() {
  try {
    const ch = new BroadcastChannel(CHANNEL_NAME + '-req');
    ch.postMessage('REQUEST_STATE');
    ch.close();
  } catch {}
}

export function readLiveState() {
  try {
    const raw = localStorage.getItem(LIVE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

// Subscribe to live-state changes pushed by the operator tab.
// Calls `callback(payload)` on every change from any tab.
// Returns an unsubscribe function.
export function subscribeLive(callback) {
  // BroadcastChannel: fires in all tabs EXCEPT the sender
  let ch = null;
  try {
    ch = new BroadcastChannel(CHANNEL_NAME);
    ch.onmessage = (e) => {
      if (e.data && typeof e.data === 'object') callback(e.data);
    };
  } catch {}

  // localStorage storage event: fires in all tabs EXCEPT the writer
  // (acts as fallback when BroadcastChannel is unavailable)
  const onStorage = (e) => {
    if (e.key === LIVE_KEY && e.newValue) {
      try { callback(JSON.parse(e.newValue)); } catch {}
    }
  };
  window.addEventListener('storage', onStorage);

  return () => {
    try { ch?.close(); } catch {}
    window.removeEventListener('storage', onStorage);
  };
}
