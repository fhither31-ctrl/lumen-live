import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  appType: 'spa',
  server: {
    proxy: {
      // Proxy /api requests to the Express AI server during development.
      // The OPENAI_API_KEY lives only in server/index.js — never in the browser.
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
      },
    },
  },
});
